-- phpMyAdmin SQL Dump
-- version 3.5.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 27, 2013 at 11:36 AM
-- Server version: 5.1.53-log
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `taome`
--

-- --------------------------------------------------------

--
-- Table structure for table `sys_file`
--

CREATE TABLE IF NOT EXISTS `sys_file` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT '0',
  `tstamp` int(11) NOT NULL DEFAULT '0',
  `crdate` int(11) NOT NULL DEFAULT '0',
  `cruser_id` int(11) NOT NULL DEFAULT '0',
  `deleted` tinyint(4) NOT NULL DEFAULT '0',
  `t3ver_oid` int(11) NOT NULL DEFAULT '0',
  `t3ver_id` int(11) NOT NULL DEFAULT '0',
  `t3ver_wsid` int(11) NOT NULL DEFAULT '0',
  `t3ver_label` varchar(30) NOT NULL DEFAULT '',
  `t3ver_state` tinyint(4) NOT NULL DEFAULT '0',
  `t3ver_stage` int(11) NOT NULL DEFAULT '0',
  `t3ver_count` int(11) NOT NULL DEFAULT '0',
  `t3ver_tstamp` int(11) NOT NULL DEFAULT '0',
  `t3ver_move_id` int(11) NOT NULL DEFAULT '0',
  `t3_origuid` int(11) NOT NULL DEFAULT '0',
  `type` varchar(10) NOT NULL DEFAULT '',
  `storage` int(11) NOT NULL DEFAULT '0',
  `identifier` varchar(200) NOT NULL DEFAULT '',
  `extension` varchar(255) NOT NULL DEFAULT '',
  `mime_type` varchar(255) NOT NULL DEFAULT '',
  `name` tinytext,
  `title` tinytext,
  `sha1` tinytext,
  `size` int(11) NOT NULL DEFAULT '0',
  `creation_date` int(11) NOT NULL DEFAULT '0',
  `modification_date` int(11) NOT NULL DEFAULT '0',
  `width` int(11) NOT NULL DEFAULT '0',
  `height` int(11) NOT NULL DEFAULT '0',
  `description` text,
  `alternative` text,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=93 ;

--
-- Dumping data for table `sys_file`
--

INSERT INTO `sys_file` (`uid`, `pid`, `tstamp`, `crdate`, `cruser_id`, `deleted`, `t3ver_oid`, `t3ver_id`, `t3ver_wsid`, `t3ver_label`, `t3ver_state`, `t3ver_stage`, `t3ver_count`, `t3ver_tstamp`, `t3ver_move_id`, `t3_origuid`, `type`, `storage`, `identifier`, `extension`, `mime_type`, `name`, `title`, `sha1`, `size`, `creation_date`, `modification_date`, `width`, `height`, `description`, `alternative`) VALUES
(1, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/about/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, '359ae0fb420fe8afe1a8b8bc5e46d75090a826b9', 637, 1361270023, 1360857256, 16, 16, NULL, NULL),
(2, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/aboutmodules/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, '9d5fc8f9fab3a3efa46c1842d4f82da55cc93a7f', 642, 1361270023, 1360857258, 16, 16, NULL, NULL),
(3, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/adodb/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, '2a54cd4dd32062ae916a12fedfee81c91cd94766', 1030, 1361270023, 1360857256, 18, 16, NULL, NULL),
(4, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/backend/ext_icon.png', 'png', 'image/png', 'ext_icon.png', NULL, 'fba9573807897088b0e67958a5f5d1ea96a50fae', 344, 1361270023, 1360857256, 16, 16, NULL, NULL),
(5, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/belog/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, 'ee7d55af61353254b82c663a3b532c53ee7324c7', 359, 1361270023, 1360857258, 16, 16, NULL, NULL),
(6, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/beuser/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, '18ea9ee90f8537b1411a9053de731c6d61de0dbd', 157, 1361270023, 1360857256, 16, 16, NULL, NULL),
(7, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/cms/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, '55d721454b6ae200c9512cc320a7f8c07a4a648e', 357, 1361270024, 1360857258, 18, 16, NULL, NULL),
(8, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/context_help/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, '3bf69d49b8f991557bdc7430d533e3cd0794234a', 619, 1361270024, 1360857256, 16, 16, NULL, NULL),
(9, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/core/ext_icon.png', 'png', 'image/png', 'ext_icon.png', NULL, 'fba9573807897088b0e67958a5f5d1ea96a50fae', 344, 1361270024, 1360857256, 16, 16, NULL, NULL),
(10, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/cshmanual/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, 'a863b8384991b598fffd6c7a3f301457ba6d49cb', 1051, 1361270024, 1360857256, 16, 16, NULL, NULL),
(11, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/css_styled_content/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, '0a78cb0d24ff27b8e1183e39d5ac6562a6e545ad', 142, 1361270024, 1360857258, 21, 18, NULL, NULL),
(12, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/dbal/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, '2feadd53a6ebcde933910d6a9ee9b00d1c4dcda6', 622, 1361270024, 1360857256, 18, 16, NULL, NULL),
(13, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/extbase/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, '23c189072cfe4edf1eb5038e4ebc62b013ccd57b', 177, 1361270024, 1360857254, 18, 16, NULL, NULL),
(14, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/extensionmanager/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, 'e67da46684aa49e6991ded936467fc063936032e', 614, 1361270024, 1360857256, 16, 16, NULL, NULL),
(15, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/extra_page_cm_options/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, 'a99cc2f0e36d9b7a146e703ad57a485096c70e5d', 241, 1361270024, 1360857254, 21, 18, NULL, NULL),
(16, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/feedit/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, '0d19ca588b292b1e94aefb6fed4e8f2db3e97433', 110, 1361270024, 1360857256, 18, 16, NULL, NULL),
(17, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/felogin/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, '3e627f00b843d94e3905b4fa490e6d41bdf9c969', 194, 1361270024, 1360857256, 21, 18, NULL, NULL),
(18, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/filelist/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, '8ee012fc11e8da3042bc9a4df1e52109406b0c59', 227, 1361270024, 1360857256, 16, 16, NULL, NULL),
(19, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/fluid/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, '23c189072cfe4edf1eb5038e4ebc62b013ccd57b', 177, 1361270024, 1360857256, 18, 16, NULL, NULL),
(20, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/form/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, '9c735e89a469f015a4a1c43b3450c783dba8cbe4', 622, 1361270025, 1360857258, 18, 16, NULL, NULL),
(21, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/frontend/ext_icon.png', 'png', 'image/png', 'ext_icon.png', NULL, 'fba9573807897088b0e67958a5f5d1ea96a50fae', 344, 1361270025, 1360857256, 16, 16, NULL, NULL),
(22, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/func/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, '530725c4a56f8b5b72efd09e6f7cf594f896e8e5', 118, 1361270025, 1360857256, 18, 12, NULL, NULL),
(23, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/func_wizards/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, '5f4b36af8d29685a9bc44d425104a49334c6d34e', 565, 1361270025, 1360857258, 16, 16, NULL, NULL),
(24, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/impexp/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, '21aa38a8577e0c6539a1dcf6bd880c381ec1de46', 229, 1361270025, 1360857258, 16, 16, NULL, NULL),
(25, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/indexed_search/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, '3b1186bfb3b1fe3ed608f68a80949b20e7414a23', 90, 1361270025, 1360857258, 15, 12, NULL, NULL),
(26, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/indexed_search_mysql/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, '3b1186bfb3b1fe3ed608f68a80949b20e7414a23', 90, 1361270025, 1360857256, 15, 12, NULL, NULL),
(27, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/info/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, 'd4e3ec69f6c7e02f9d2c5d749024bf46ab0c22e1', 1000, 1361270025, 1360857256, 16, 16, NULL, NULL),
(28, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/info_pagetsconfig/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, 'fb0fb3390936ad820c5b7436cd87d442123bd33d', 619, 1361270025, 1360857256, 21, 18, NULL, NULL),
(29, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/install/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, '1e092ba01ec0babe2fe1b22b67c45de899c484c8', 601, 1361270025, 1360857258, 16, 16, NULL, NULL),
(30, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/lang/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, 'f35e159406d07c9675830bc51ef14a210f1cab1f', 581, 1361270026, 1360857256, 16, 16, NULL, NULL),
(31, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/linkvalidator/ext_icon.gif', 'gif', 'image/png', 'ext_icon.gif', NULL, 'cdada35018dfbdd57e6442ea038a0314677d9114', 918, 1361270026, 1360857256, 16, 16, NULL, NULL),
(32, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/lowlevel/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, 'c182aec01a3225de5f72ef272d0e8a59ec670d93', 82, 1361270026, 1360857258, 14, 12, NULL, NULL),
(33, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/opendocs/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, '54f00d2070213715d290f2f813601a27c5277869', 84, 1361270026, 1360857254, 14, 12, NULL, NULL),
(34, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/openid/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, '734c40675f05fd730cea8e39c77af5eb47cc4d9b', 346, 1361270026, 1360857256, 16, 16, NULL, NULL),
(35, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/perm/ext_icon.gif', 'gif', 'image/png', 'ext_icon.gif', NULL, '03717e1ac333d0bef7a33a3ceff1305ef6deecbc', 733, 1361270026, 1360857258, 16, 16, NULL, NULL),
(36, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/recordlist/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, '332e96b6dac59bffa4dbf87137e1fee4f44bd5d3', 129, 1361270026, 1360857256, 16, 16, NULL, NULL),
(37, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/recycler/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, '1861cc8eecb71a20e757de83386ba3841ab4da1d', 349, 1361270026, 1360857256, 16, 16, NULL, NULL),
(38, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/reports/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, 'ee7d55af61353254b82c663a3b532c53ee7324c7', 359, 1361270026, 1360857256, 16, 16, NULL, NULL),
(39, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/rsaauth/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, '70c2aab11e104ec14fc3934f28201630d0935b8a', 850, 1361270026, 1360857258, 16, 16, NULL, NULL),
(40, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/rtehtmlarea/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, '5061eebad398d086cc5dfafb2182c159a723af56', 161, 1361270026, 1360857258, 18, 16, NULL, NULL),
(41, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/saltedpasswords/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, 'a6a08a082b189dd1f669595ac91fc90fde913e23', 282, 1361270026, 1360857256, 16, 16, NULL, NULL),
(42, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/scheduler/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, '405729c40df7f0e38105583492a8d33bae1db0fe', 667, 1361270026, 1360857258, 16, 16, NULL, NULL),
(43, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/setup/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, 'efba11523cbede8368582445e9036f4eab580d3f', 231, 1361270027, 1360857256, 16, 16, NULL, NULL),
(44, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/statictemplates/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, '7fead63028fde7503475b6121751df8a634bde61', 369, 1361270027, 1360857256, 16, 16, NULL, NULL),
(45, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/sv/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, '55d721454b6ae200c9512cc320a7f8c07a4a648e', 357, 1361270027, 1360857256, 18, 16, NULL, NULL),
(46, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/sys_action/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, 'fdd57620b7a3a3e9755595363fa207af86f598ff', 630, 1361270027, 1360857254, 16, 16, NULL, NULL),
(47, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/sys_note/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, '7a97bb0a5cc6e5e0339a1a90f28094a7a41c693f', 156, 1361270027, 1360857254, 18, 16, NULL, NULL),
(48, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/t3editor/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, 'fb9c533ec6c7536c0f5b4049994d3f9aba80121f', 1023, 1361270027, 1360857256, 16, 16, NULL, NULL),
(49, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/t3skin/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, 'ad4e9bb93928007bad9b98c36a794eaa86544308', 254, 1361270027, 1360857254, 21, 18, NULL, NULL),
(50, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/taskcenter/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, 'b4f17c0cd49f4ac83b3fe99946d4df7861f01962', 167, 1361270028, 1360857256, 16, 16, NULL, NULL),
(51, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/tsconfig_help/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, 'ce2ce494584ed2b1dae4639a17531a5ea7295dab', 1049, 1361270028, 1360857254, 16, 16, NULL, NULL),
(52, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/tstemplate/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, '9aa8f313a25f48c65529acdf796557f3149c3c74', 99, 1361270028, 1360857258, 17, 12, NULL, NULL),
(53, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/tstemplate_analyzer/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, '18b089a7e39a2831d775c54d9b4ad781810dbb0b', 366, 1361270028, 1360857256, 21, 18, NULL, NULL),
(54, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/tstemplate_ceditor/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, 'bbcb0ff3d075efe84d03ac8a039fcad4dd1027e9', 134, 1361270028, 1360857258, 21, 18, NULL, NULL),
(55, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/tstemplate_info/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, 'e5cc70deccb28078e5840223c70e15a9f70b3de9', 194, 1361270028, 1360857258, 21, 18, NULL, NULL),
(56, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/tstemplate_objbrowser/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, '56a3a27afae4d201ccbb9b1cd73717e94bb7a940', 203, 1361270028, 1360857258, 21, 18, NULL, NULL),
(57, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/version/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, '61c9380cfa98ccc2dbbe8e9bcc94081815bf6109', 383, 1361270028, 1360857258, 16, 16, NULL, NULL),
(58, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/viewpage/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, '9d5ce162e3a36bc67590ba0c1a5360ab2a83d2e8', 367, 1361270028, 1360857258, 16, 16, NULL, NULL),
(59, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/wizard_crpages/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, 'db136645cf980646e414fc50b7c35e9f4a049143', 649, 1361270028, 1360857256, 21, 18, NULL, NULL),
(60, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/wizard_sortpages/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, '86de0fe6bfe0d29b7bf4771b13dde1fc206336a6', 206, 1361270028, 1360857258, 21, 18, NULL, NULL),
(61, 0, 1361270750, 1361270750, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '2', 0, '/typo3/sysext/workspaces/ext_icon.gif', 'gif', 'image/gif', 'ext_icon.gif', NULL, '1d8dd277a444da23b8c4d4da51b477dccacd21de', 374, 1361270028, 1360857258, 16, 16, NULL, NULL),
(62, 0, 1361977375, 1361977375, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '0', 0, '/typo3conf/ext/firstsquare_base_href/ext_icon.gif', 'gif', '', 'ext_icon.gif', NULL, 'ee28d99655949dab9653d428e349dc1bf0651ba4', 1723, 1361961158, 1361961158, 0, 0, NULL, NULL),
(63, 0, 1361980411, 1361980411, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '0', 0, '/typo3conf/ext/realurl/ext_icon.gif', 'gif', '', 'ext_icon.gif', NULL, '3cec3a19c546a2624f7de555c8be48c9652d46f1', 207, 1361980398, 1361980398, 0, 0, NULL, NULL),
(64, 0, 1362048985, 1362048985, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '0', 0, '/typo3/clear.gif', 'gif', '', 'clear.gif', NULL, '1c96ed6597e58f0137be85708bd5c344da60de9f', 46, 1361980945, 1360857030, 0, 0, NULL, NULL),
(65, 0, 1362053600, 1362053600, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '0', 1, '/Upload/German/StartseiteKopfbereich/Beispiel1.jpg', 'jpg', '', 'Beispiel1.jpg', NULL, '0eea605c5974d8b0b3ffb73b3bb12f55170703c0', 551856, 1362050093, 1362050094, 0, 0, NULL, NULL),
(66, 0, 1362053600, 1362053600, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '0', 1, '/Upload/German/StartseiteKopfbereich/Beispiel2.jpg', 'jpg', '', 'Beispiel2.jpg', NULL, '78246d87aa8b24779b01eb39e8850168f1745ca5', 606498, 1362050117, 1362050117, 0, 0, NULL, NULL),
(67, 0, 1362053600, 1362053600, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '0', 1, '/Upload/German/StartseiteKopfbereich/Beispiel3.jpg', 'jpg', '', 'Beispiel3.jpg', NULL, 'e2b54533051181f29d607583759a394e276f616e', 269653, 1362053526, 1362053527, 0, 0, NULL, NULL),
(68, 0, 1362053600, 1362053600, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '0', 1, '/Upload/German/StartseiteKopfbereich/Beispiel4.jpg', 'jpg', '', 'Beispiel4.jpg', NULL, 'a5a194d543c63ec5d73ff0ebf71ae5a4b051ce39', 318197, 1362053536, 1362053536, 0, 0, NULL, NULL),
(69, 0, 1362062749, 1362062749, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '0', 0, '/fileadmin/Upload/German/StartseiteKopfbereich/Beispiel1.jpg', 'jpg', '', 'Beispiel1.jpg', NULL, '0eea605c5974d8b0b3ffb73b3bb12f55170703c0', 551856, 1362050093, 1362050094, 0, 0, NULL, NULL),
(70, 0, 1362062749, 1362062749, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '0', 0, '/fileadmin/Upload/German/StartseiteKopfbereich/Beispiel2.jpg', 'jpg', '', 'Beispiel2.jpg', NULL, '78246d87aa8b24779b01eb39e8850168f1745ca5', 606498, 1362050117, 1362050117, 0, 0, NULL, NULL),
(71, 0, 1362062749, 1362062749, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '0', 0, '/fileadmin/Upload/German/StartseiteKopfbereich/Beispiel3.jpg', 'jpg', '', 'Beispiel3.jpg', NULL, 'e2b54533051181f29d607583759a394e276f616e', 269653, 1362053526, 1362053527, 0, 0, NULL, NULL),
(72, 0, 1362062749, 1362062749, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '0', 0, '/fileadmin/Upload/German/StartseiteKopfbereich/Beispiel4.jpg', 'jpg', '', 'Beispiel4.jpg', NULL, 'a5a194d543c63ec5d73ff0ebf71ae5a4b051ce39', 318197, 1362053536, 1362053536, 0, 0, NULL, NULL),
(73, 0, 1362399531, 1362399531, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '0', 0, '/typo3conf/ext/taome/ext_icon.gif', 'gif', '', 'ext_icon.gif', NULL, '1fd3ec55889b34bc3fa9f3ce43e98898105a6d61', 1622, 1362046207, 1362046121, 0, 0, NULL, NULL),
(74, 0, 1362399857, 1362399857, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '0', 0, '/typo3conf/ext/extdeveval/ext_icon.gif', 'gif', '', 'ext_icon.gif', NULL, '313241dea6c8528fa49724a5ef361fdde5f72cda', 359, 1362399847, 1362399847, 0, 0, NULL, NULL),
(75, 0, 1362400848, 1362400848, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '0', 0, '/typo3conf/ext/extension_builder/ext_icon.gif', 'gif', '', 'ext_icon.gif', NULL, '23c189072cfe4edf1eb5038e4ebc62b013ccd57b', 177, 1362400844, 1362400844, 0, 0, NULL, NULL),
(76, 0, 1362479636, 1362479636, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '0', 1, '/Upload/Shared/Teaser/Brochure.png', 'png', '', 'Brochure.png', NULL, 'a093b3a60403a90e5c6b250a1fc4cc9597dfa930', 38278, 1362479599, 1362479599, 0, 0, NULL, NULL),
(77, 0, 1362479896, 1362479896, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '0', 1, '/Upload/German/Flyer/ANSICHT_TAOme_Flyer_DIN-Lang.pdf', 'pdf', '', 'ANSICHT_TAOme_Flyer_DIN-Lang.pdf', NULL, 'ecc3f148f61a46bfcf0d28a522abc41119fe0b65', 970875, 1362479862, 1339427863, 0, 0, NULL, NULL),
(78, 0, 1362480209, 1362480209, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '0', 1, '/Upload/Shared/Teaser/BrochureTest.jpg', 'jpg', '', 'BrochureTest.jpg', NULL, '84ecd3c1043a527d40a3b09535bc7beebb17e7fa', 8614, 1362480187, 1362480187, 0, 0, NULL, NULL),
(79, 0, 1362484776, 1362484776, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '0', 1, '/Upload/100x100.jpg', 'jpg', '', '100x100.jpg', NULL, 'ea799200994e20072aa9945c6a0fcbf2b76ff442', 1253, 1362484775, 1362484775, 0, 0, NULL, NULL),
(80, 0, 1362505197, 1362505197, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '0', 0, '/typo3conf/ext/formhandler/ext_icon.gif', 'gif', '', 'ext_icon.gif', NULL, '2a2dfbdb2076b3a323a75f8526273c4c28aad8ec', 301, 1362505184, 1362505184, 0, 0, NULL, NULL),
(81, 0, 1362574768, 1362574768, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '0', 1, '/Upload/b_100x100.jpg', 'jpg', '', 'b_100x100.jpg', NULL, 'ea799200994e20072aa9945c6a0fcbf2b76ff442', 1253, 1362574767, 1362574767, 0, 0, NULL, NULL),
(82, 0, 1362761886, 1362761886, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '0', 0, '/fileadmin/Upload/German/Fusszeile/Philosophie.png', 'png', '', 'Philosophie.png', NULL, 'c235fe55c3f264f0684ca295398ebe578687cfe6', 42433, 1362760448, 1362760448, 0, 0, NULL, NULL),
(83, 0, 1362762231, 1362762231, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '0', 0, '/fileadmin/Upload/German/Fusszeile/DerBreisgau.png', 'png', '', 'DerBreisgau.png', NULL, '6179badd2f106fbb6f37a5788fdff3507f7c1e52', 134672, 1362760518, 1362760518, 0, 0, NULL, NULL),
(84, 0, 1362763050, 1362763050, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '0', 0, '/fileadmin/Upload/English/Footer/Philosophie.png', 'png', '', 'Philosophie.png', NULL, 'f8f2884c54598cfe471d9ae93413cc95e0aace23', 43112, 1362760481, 1362760481, 0, 0, NULL, NULL),
(85, 0, 1362763050, 1362763050, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '0', 0, '/fileadmin/Upload/English/Footer/DerBreisgau.png', 'png', '', 'DerBreisgau.png', NULL, 'f39e10cefe590c1031ca8363ab54cf72df647490', 134768, 1362760540, 1362760541, 0, 0, NULL, NULL),
(86, 0, 1363279260, 1363279260, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '0', 0, '/typo3conf/ext/firstsquare_responsive/ext_icon.gif', 'gif', '', 'ext_icon.gif', NULL, '1fd3ec55889b34bc3fa9f3ce43e98898105a6d61', 1622, 1363278924, 1363278924, 0, 0, NULL, NULL),
(87, 0, 1363776601, 1363776601, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '0', 1, '/Upload/German/Startseite/Karte.jpg', 'jpg', '', 'Karte.jpg', NULL, '8b309f05dab18fe1bf826ea5775bf284a2ef9c95', 15965, 1363776392, 1363776447, 0, 0, NULL, NULL),
(88, 0, 1363781250, 1363781250, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '0', 1, '/Upload/German/Fusszeile/DerBreisgau.png', 'png', '', 'DerBreisgau.png', NULL, '6179badd2f106fbb6f37a5788fdff3507f7c1e52', 134672, 1362760518, 1362760518, 0, 0, NULL, NULL),
(89, 0, 1363781250, 1363781250, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '0', 1, '/Upload/German/Fusszeile/Philosophie.png', 'png', '', 'Philosophie.png', NULL, 'c235fe55c3f264f0684ca295398ebe578687cfe6', 42433, 1362760448, 1362760448, 0, 0, NULL, NULL),
(90, 0, 1363781274, 1363781274, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '0', 1, '/Upload/English/Footer/DerBreisgau.png', 'png', '', 'DerBreisgau.png', NULL, 'f39e10cefe590c1031ca8363ab54cf72df647490', 134768, 1362760540, 1362760541, 0, 0, NULL, NULL),
(91, 0, 1363781274, 1363781274, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '0', 1, '/Upload/English/Footer/Philosophie.png', 'png', '', 'Philosophie.png', NULL, 'f8f2884c54598cfe471d9ae93413cc95e0aace23', 43112, 1362760481, 1362760481, 0, 0, NULL, NULL),
(92, 0, 1363783829, 1363783829, 0, 0, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, '0', 1, '/Upload/English/Startpage/Map.jpg', 'jpg', '', 'Map.jpg', NULL, 'e351594edd8641ab8a1c008135bc01d97540c826', 15294, 1363783809, 1363783810, 0, 0, NULL, NULL);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
