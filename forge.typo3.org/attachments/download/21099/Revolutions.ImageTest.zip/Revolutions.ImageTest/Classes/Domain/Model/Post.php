<?php
namespace Revolutions\ImageTest\Domain\Model;

/*                                                                        *
 * This script belongs to the FLOW3 package "Revolutions.ImageTest".      *
 *                                                                        *
 *                                                                        */

use TYPO3\FLOW3\Annotations as FLOW3;
use Doctrine\ORM\Mapping as ORM;

/**
 * A Post
 *
 * @FLOW3\Entity
 */
class Post {

	/**
	 * The title
	 * @var string
	 */
	protected $title;

	/**
	 * The bodytext
	 * @var string
     * @ORM\Column(type="text")
	 */
	protected $bodytext;

	/**
	 * The image
	 * @var \TYPO3\Media\Domain\Model\Image
     * @ORM\OneToOne(cascade={"all"}, orphanRemoval=true)
	 */
	protected $image;


	/**
	 * Get the Post's title
	 *
	 * @return string The Post's title
	 */
	public function getTitle() {
		return $this->title;
	}

	/**
	 * Sets this Post's title
	 *
	 * @param string $title The Post's title
	 * @return void
	 */
	public function setTitle($title) {
		$this->title = $title;
	}

	/**
	 * Get the Post's bodytext
	 *
	 * @return string The Post's bodytext
	 */
	public function getBodytext() {
		return $this->bodytext;
	}

	/**
	 * Sets this Post's bodytext
	 *
	 * @param string $bodytext The Post's bodytext
	 * @return void
	 */
	public function setBodytext($bodytext) {
		$this->bodytext = $bodytext;
	}

	/**
	 * Get the Post's image
	 *
	 * @return \TYPO3\Media\Domain\Model\Image The Post's image
	 */
	public function getImage() {
		return $this->image;
	}

	/**
	 * Sets this Post's image
	 *
	 * @param \TYPO3\Media\Domain\Model\Image $image The Post's image
	 * @return void
	 */
	public function setImage(\TYPO3\Media\Domain\Model\Image $image) {
		$this->image = $image;
	}

}
?>