<?php
namespace Revolutions\ImageTest\Controller;

/*                                                                        *
 * This script belongs to the FLOW3 package "Revolutions.ImageTest".      *
 *                                                                        *
 *                                                                        */

use TYPO3\FLOW3\Annotations as FLOW3;

use TYPO3\FLOW3\Mvc\Controller\ActionController;
use \Revolutions\ImageTest\Domain\Model\Post;

/**
 * Post controller for the Revolutions.ImageTest package 
 *
 * @FLOW3\Scope("singleton")
 */
class PostController extends ActionController {

	/**
	 * @FLOW3\Inject
	 * @var \Revolutions\ImageTest\Domain\Repository\PostRepository
	 */
	protected $postRepository;

	/**
	 * Shows a list of posts
	 *
	 * @return void
	 */
	public function indexAction() {
		$this->view->assign('posts', $this->postRepository->findAll());
	}

	/**
	 * Shows a single post object
	 *
	 * @param \Revolutions\ImageTest\Domain\Model\Post $post The post to show
	 * @return void
	 */
	public function showAction(Post $post) {
		$this->view->assign('post', $post);
	}

	/**
	 * Shows a form for creating a new post object
	 *
	 * @return void
	 */
	public function newAction() {
	}

	/**
	 * Adds the given new post object to the post repository
	 *
	 * @param \Revolutions\ImageTest\Domain\Model\Post $newPost A new post to add
	 * @return void
	 */
	public function createAction(Post $newPost) {
		$this->postRepository->add($newPost);
		$this->addFlashMessage('Created a new post.');
		$this->redirect('index');
	}

	/**
	 * Shows a form for editing an existing post object
	 *
	 * @param \Revolutions\ImageTest\Domain\Model\Post $post The post to edit
	 * @return void
	 */
	public function editAction(Post $post) {
		$this->view->assign('post', $post);
	}

	/**
	 * Updates the given post object
	 *
	 * @param \Revolutions\ImageTest\Domain\Model\Post $post The post to update
	 * @return void
	 */
	public function updateAction(Post $post) {
		$this->postRepository->update($post);
		$this->addFlashMessage('Updated the post.');
		$this->redirect('index');
	}

	/**
	 * Removes the given post object from the post repository
	 *
	 * @param \Revolutions\ImageTest\Domain\Model\Post $post The post to delete
	 * @return void
	 */
	public function deleteAction(Post $post) {
		$this->postRepository->remove($post);
		$this->addFlashMessage('Deleted a post.');
		$this->redirect('index');
	}

}

?>