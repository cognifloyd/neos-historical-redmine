.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: Includes.txt


.. _labels-for-crossreferencing:

Index: Labels for Cross-referencing
===================================

.. ref-targets-list::
