<?php
namespace TYPO3\Fluid\Service;

/*                                                                        *
 * This script belongs to the TYPO3 Flow package "Fluid".                 *
 *                                                                        *
 * It is free software; you can redistribute it and/or modify it under    *
 * the terms of the GNU Lesser General Public License, either version 3   *
 * of the License, or (at your option) any later version.                 *
 *                                                                        *
 * The TYPO3 project - inspiring people to share!                         *
 *                                                                        */


/**
 * @Flow\Scope("singleton")
 */
use TYPO3\Flow\Annotations as Flow;

/**
 * Generates a unique form id
 */
class FormIDGenerator {

	/**
     * simple counter
     */
    protected $counter=0;


    /**
     * return an unique id
     */
    public function generateID(){
        $this->counter++;
        return md5($this->counter);
    }

    /**
     * return the current id
     */
    public function getCurrentID(){
        return md5($this->counter);
    }

}
?>