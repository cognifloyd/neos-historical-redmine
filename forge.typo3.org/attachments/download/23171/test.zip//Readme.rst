Extension Manual
=================

This is a template manual aiming to pave the way to developers when it comes about documentation. The template provides a structure that a developer can take over and, in addition, many useful snippets and examples. Documentation is written in reST format. Refer to Help writing reStructuredText to get some more insight about the syntax and available reST editors. For instance, you might be particularly interested how you can :

* generate the documentation using on-line services (@todo to write) 
* `make links`_ accros projects
* how you should write TypoScript reference.

Any idea or suggestion for improving this template `can be drop`_ to our team_. And remember: documentation is like gift wrapping, it looks like superfluous, but your friend tends to be rather disappointed when their presents arrive in supermarket carrier bags. (Documentation-Driven Design quote)

.. _can be drop: http://forge.typo3.org/projects/typo3v4-official_extension_template/issues
.. _team: http://forge.typo3.org/projects/typo3v4-official_extension_template
.. _make links: RestructuredtextHelp.html#cross-linking
.. _can write TypoScript: RestructuredtextHelp.html#typoscript-reference
