﻿========================
Manuel utilisateur
========================

This is a place where the translation of the User Manual could be possibly added. This could be handy when a company is compiling a documentation towards the End User in a native language. It has the possibility to include this file in the build process.

Comment installer et utiliser l'extension du point de vue de l'utilisateur.

Copie d'écran indispensable.

.. figure:: Images/UserManualFr/BackendView.png
		:width: 500px
		:alt: Backend view

		Vue par défaut du Backend (caption tag)

		La vue Backend par défaut du module "Page". (legend tag)
