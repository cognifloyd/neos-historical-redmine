<?php
namespace Test\ValueObject\Controller;

use Test\ValueObject\Domain\Model\Entity;
use Test\ValueObject\Domain\Model\ValueObject;
use Test\ValueObject\Domain\Repository\EntityRepository;
use TYPO3\Flow\Annotations as Flow;
use TYPO3\Flow\Mvc\Controller\ActionController;

class EntityController extends ActionController {

	/**
	 * @var EntityRepository
	 * @Flow\Inject
	 */
	protected $entityRepository;

	public function indexAction() {
		/** @var Entity $entity */
		$entity = $this->entityRepository->findAll()->getFirst();
		$this->view->assign('entity', $entity);
	}

	public function createDummyEntityAction() {
		$entity = new Entity();
		$this->entityRepository->add($entity);
		$this->redirect('index');
	}

	/**
	 * @param ValueObject $valueObject
	 */
	public function addValueObjectAction(ValueObject $valueObject) {
		/** @var Entity $entity */
		$entity = $this->entityRepository->findAll()->getFirst();
		$entity->addValueObject($valueObject);
		$this->entityRepository->update($entity);
		$this->redirect('index');
	}

	/**
	 * @param ValueObject $valueObject
	 */
	public function removeValueObjectAction(ValueObject $valueObject) {
		/** @var Entity $entity */
		$entity = $this->entityRepository->findAll()->getFirst();
		$entity->removeValueObject($valueObject);
		$this->entityRepository->update($entity);
		$this->redirect('index');
	}

}