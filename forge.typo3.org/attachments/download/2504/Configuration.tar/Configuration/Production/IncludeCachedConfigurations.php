<?php
	if (file_exists('/var/www/dev.simplaweb.at/Data/Temporary/b558487516b7/Configuration/ProductionConfigurations.php') && \F3\FLOW3\Core\Bootstrap::REVISION === '$Revision: 3643 $') {
		return require '/var/www/dev.simplaweb.at/Data/Temporary/b558487516b7/Configuration/ProductionConfigurations.php';
	} else {
		unlink(__FILE__);
		return array();
	}
?>