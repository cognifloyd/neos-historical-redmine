<?php
declare(ENCODING = 'utf-8');
namespace F3\JSTesting\Controller;

/*                                                                        *
 * This script belongs to the FLOW3 package "JSTesting".                    *
 *                                                                        *
 * It is free software; you can redistribute it and/or modify it under    *
 * the terms of the GNU General Public License as published by the Free   *
 * Software Foundation, either version 3 of the License, or (at your      *
 * option) any later version.                                             *
 *                                                                        *
 * This script is distributed in the hope that it will be useful, but     *
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHAN-    *
 * TABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General      *
 * Public License for more details.                                       *
 *                                                                        *
 * You should have received a copy of the GNU General Public License      *
 * along with the script.                                                 *
 * If not, see http://www.gnu.org/licenses/gpl.html                       *
 *                                                                        *
 * The TYPO3 project - inspiring people to share!                         *
 *                                                                        */

/**
 * Controller for the JavaScript Testing package
 *
 * @license http://www.gnu.org/licenses/gpl.html GNU General Public License, version 3 or later
 */
class StandardController extends \F3\FLOW3\MVC\Controller\ActionController {

	/**
	 * @var \F3\JSTesting\Services\PackageService
	 * @inject
	 */
	private $packageService;

	/**
	 * Default index action
	 *
	 * @return void
	 */
	public function indexAction() {
		$this->view->assign('testClasses', $this->packageService->getTestClasses());
		$this->view->assign('includes', $this->packageService->getIncludeFiles());
	}

	/**
	 * Script action, this action concatenates all javascripts and outputs it
	 *
	 * @return void
	 */
	public function scriptAction() {
		header('Content-type: application/x-javascript');

		$str = '';
		
		$packageFiles = $this->packageService->getClassFiles();
		foreach ($packageFiles as $packageFileList) {
			foreach ($packageFileList as $file) {
				$str .= \F3\FLOW3\Utility\Files::getFileContents($file);
			}
		}

		$this->view->assign('script', $str);
	}
}

?>