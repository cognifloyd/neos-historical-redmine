<?php
declare(ENCODING = 'utf-8');
namespace F3\JSTesting\Services;

/*                                                                        *
 * This script belongs to the FLOW3 package "JSTesting".                    *
 *                                                                        *
 * It is free software; you can redistribute it and/or modify it under    *
 * the terms of the GNU General Public License as published by the Free   *
 * Software Foundation, either version 3 of the License, or (at your      *
 * option) any later version.                                             *
 *                                                                        *
 * This script is distributed in the hope that it will be useful, but     *
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHAN-    *
 * TABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General      *
 * Public License for more details.                                       *
 *                                                                        *
 * You should have received a copy of the GNU General Public License      *
 * along with the script.                                                 *
 * If not, see http://www.gnu.org/licenses/gpl.html                       *
 *                                                                        *
 * The TYPO3 project - inspiring people to share!                         *
 *                                                                        */

/**
 * Controller for the JavaScript Testing package
 *
 * @license http://www.gnu.org/licenses/gpl.html GNU General Public License, version 3 or later
 */
class PackageService {

	/**
	 * @var array Contains the list of package with test classes
	 */
	private $packages;

	/**
	 * @var array Contains the list with test class files
	 */
	private $classFiles;

	/**
	 * @var array Contains the list with test class names
	 */
	private $testClasses;

	/**
	 * @var array Contains the list with annotated includes in the test classes
	 */
	private $includes;

	/**
	 * @var F3\FLOW3\Package\PackageManagerInterface
	 * @inject
	 */
	private $packageManager;

	/**
	 * This method initalizes the object, and starts the extraction of
	 * metadata
	 */
	public function initializeObject() {
		$this->findPackagesWithATestClassDirectory();
		$this->getTestClassFileNames();
		$this->extraDataFromTestClassFiles();
	}

	/**
	 * This method iterates through all active packages, and filters
	 * those which contain a Tests/JavaScript folder
	 *
	 * @return void
	 */
	private function findPackagesWithATestClassDirectory() {
		$packages = $this->packageManager->getActivePackages();

		foreach ($packages as $package) {
			if (is_dir($package->getPackagePath() . 'Tests/JavaScript')) {
				$this->packages[] = $package;
			}
		}
	}

	/**
	 * This method opens all testClass files, and extracts the class name and
	 * includes from the file
	 *
	 * @return void
	 */
	private function extraDataFromTestClassFiles() {
		$this->testClasses	= array();
		$this->includes		= array();

		foreach ($this->packages as $package) {
			foreach ($this->classFiles[$package->getPackageKey()] as $fileName) {
				$fileContent = \F3\FLOW3\Utility\Files::getFileContents($fileName);

				// Get classname
				preg_match("/(F3\.[^ \n]*Test)[ ]?=/", $fileContent, $className);
				if (!empty($className[1])) {
					$this->testClasses[] = $className[1];
				}

				// Get includes
				preg_match_all("/\@include[ ]*([^ \n]*)/", $fileContent, $includes);
				if (!empty($includes[1])) {
					foreach ($includes[1] as $include) {
						$data = explode(':', $include);
						if ($this->packageManager->isPackageActive($data[0])) {
							$package = $this->packageManager->getPackage($data[0]);

							$this->includes[$include] = array(
								'packageKey' => $package->getPackageKey(),
								'path' => $data[1]
							);
						}
					}
				}

			}
		}
	}

	/**
	 * This method fetches all *Test.js files from the Package/Tests/JavaScript folder
	 *
	 * @return void
	 */
	private function getTestClassFileNames() {
		$this->classFiles = array();

		foreach ($this->packages as $package) {
			$this->classFiles[$package->getPackageKey()] = \F3\FLOW3\Utility\Files::readDirectoryRecursively($package->getPackagePath() . 'Tests/JavaScript', '.js');
			foreach ($this->classFiles[$package->getPackageKey()] as $index => $fileName) {
				if (strpos($fileName, 'Test.js') === false) {
					unset($this->classFiles[$package->getPackageKey()][$index]);
				}
			}
		}
	}

	/**
	 * Getter method for the includes
	 *
	 * @return array
	 */
	public function getIncludeFiles() {
		return $this->includes;
	}

	/**
	 * Getter method for the list of test class names
	 *
	 * @return array
	 */
	public function getTestClasses() {
		return $this->testClasses;
	}

	/**
	 * Getter method for the list of test class filenames
	 *
	 * @return array
	 */
	public function getClassFiles() {
		return $this->classFiles;
	}
}

?>