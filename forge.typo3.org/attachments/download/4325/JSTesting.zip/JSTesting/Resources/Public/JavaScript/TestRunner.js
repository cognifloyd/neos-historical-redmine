YUI({
	logInclude: { TestRunner: true },
	lang: 'en'
}).use('node', 'test', 'console', 'intl', function(Y){
	Y.on("domready", run);
	function run() {
			//create a test suite
		var suite = new Y.Test.Suite("AllTests");
		Ext.each(testClasses, function(testClassName) {
			suite.add(new Y.Test.Case(eval(testClassName)));
		});
			//initialize the console
		var yconsole = new Y.Console({
			newestOnTop: false,
			verbose: true,
			height:'500px',
			width:'95%',
			style:'block'
		});
		yconsole.render('#log');

			//run the tests
		window.Y = Y;
		Y.Test.Runner.add(suite);
		Y.Test.Runner.run();
	}
});