<?php

/***************************************************************
 * Extension Manager/Repository config file for ext "eid_test".
 *
 * Auto generated 07-09-2014 16:37
 *
 * Manual updates:
 * Only the data in the array - everything else is removed by next
 * writing. "version" and "dependencies" must not be touched!
 ***************************************************************/

$EM_CONF[$_EXTKEY] = array(
	'title' => 'eID-Test-Extension',
	'description' => 'This package delivers several eID-Tests to measure performance',
	'category' => 'misc',
	'version' => '0.0.1',
	'state' => 'alpha',
	'uploadfolder' => 0,
	'createDirs' => '',
	'clearcacheonload' => 0,
	'author' => 'Stephan Großberndt',
	'author_email' => 's.grossberndt@sidebysite.de',
	'author_company' => 'side by site GmbH & Co. KG',
	'constraints' => array(
		'depends' => array(
			'typo3' => '4.5.0-6.3.999',
		),
		'conflicts' => array(
		),
		'suggests' => array(
		),
	),
	'_md5_values_when_last_written' => 'a:14:{s:12:"eid_test.php";s:4:"aea7";s:15:"eid_test_db.php";s:4:"f0d7";s:22:"eid_test_db_feuser.php";s:4:"2594";s:19:"eid_test_feuser.php";s:4:"7c1d";s:17:"ext_localconf.php";s:4:"0e13";s:26:"logs/45-test-db-feuser.log";s:4:"618c";s:19:"logs/45-test-db.log";s:4:"7e71";s:23:"logs/45-test-feuser.log";s:4:"7fcc";s:16:"logs/45-test.log";s:4:"0780";s:26:"logs/62-test-db-feuser.log";s:4:"fc46";s:19:"logs/62-test-db.log";s:4:"7761";s:23:"logs/62-test-feuser.log";s:4:"e597";s:16:"logs/62-test.log";s:4:"dba0";s:17:"logs/eid_test.bat";s:4:"1b83";}',
);

?>