<?php
declare(ENCODING = 'utf-8');

/*                                                                        *
 * This script is part of the TYPO3 project - inspiring people to share!  *
 *                                                                        *
 * TYPO3 is free software; you can redistribute it and/or modify it under *
 * the terms of the GNU General Public License version 2 as published by  *
 * the Free Software Foundation.                                          *
 *                                                                        *
 * This script is distributed in the hope that it will be useful, but     *
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHAN-    *
 * TABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General      *
 * Public License for more details.                                       *
 *                                                                        */ 

/**
 * The default controller of the InterfaceTest
 * 
 * @package		InterfaceTest
 * @version 	
 * @copyright	Copyright belongs to the respective authors
 * @license		http://opensource.org/licenses/gpl-license.php GNU Public License, version 2
 */
class T3_InterfaceTest_Controller_Default extends T3_FLOW3_MVC_Controller_RequestHandlingController {
	
	protected $componentManager;


	public function __construct(T3_FLOW3_Component_ManagerInterface $componentManager) {
      $this->componentManager = $componentManager;
   }
	/**
	 * Handles a request
	 *
	 * @param  T3_FLOW3_MVC_Request 		$request: The request object
	 * @param  T3_FLOW3_MVC_Response		$respone: The response, modified by this handler
	 * @return void
	 */
	public function processRequest(T3_FLOW3_MVC_Request $request, T3_FLOW3_MVC_Response $response) {
		
		$connection=$this->componentManager->getComponent('T3_InterfaceTest_ConcreteConnection');
		
		switch (get_class($request)) {
			case 'T3_FLOW3_MVC_Web_Request' :
				$response->setContent('XQuery - WEBREQUEST');	 	
				break;
			case 'T3_FLOW3_MVC_CLI_Request' :
				$response->setContent('XQuery - CLI');
				break;	 	
			default :
				$response->setContent('XQuery Default Controller - unknown request type.');	 	
		}
	}
}

?>
