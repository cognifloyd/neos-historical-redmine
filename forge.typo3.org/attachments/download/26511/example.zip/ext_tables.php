<?php
if (!defined ('TYPO3_MODE')) die ('Access denied.');

include($absPath.'Configuration/TCA/Test.php');

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::makeCategorizable(
	$_EXTKEY,
	'tx_example_domain_model_test',
	'categories',
	array ( )
);

?>