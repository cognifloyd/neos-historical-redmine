<?php

$GLOBALS['TCA']['tx_example_domain_model_test'] = array (
	'ctrl' => array (
		'title' => 'TEST',
		'label' => 'title',
		'tstamp' => 'tstamp',
		'crdate' => 'crdate',
		'cruser_id' => 'cruser_uid',
		'sortby' => 'title',
		'delete' => 'deleted',
		'enablecolumns' => array(
			'disabled' => 'hidden'
		)
	),
	'interface' => array(
		'showRecordFieldList' => 'title',
		'maxDBListItems' => 50,
		'maxSingleDBListItems' => 100
	),
	'columns' => array(
		
		'title' => array(
			'exclude' => 0,
			'label' => 'TITLE',
			'config' => array(
				'type' => 'input',
				'size' => 20,
				'eval' => 'trim',
				'max' => 80
			)
		),
	),
	'types' => array(
		'1' => array('showitem' => 'title')
	)
);
?>