<?php
$EM_CONF[$_EXTKEY] = array(
	'title' => 'Example',
	'description' => 'foo',
	'category' => 'backend,frontend',
	'shy' => 0,
	'version' => '1.0.0',
	'dependencies' => '',
	'conflicts' => '',
	'priority' => '',
	'loadOrder' => '10',
	'TYPO3_version' => '6.2.0-6.2.99',
	'PHP_version' => '5.3.0-0.0.0',
	'module' => '',
	'state' => 'alpha',
	'uploadfolder' => 0,
	'createDirs' => '',
	'modify_tables' => '',
	'clearcacheonload' => 1,
	'lockType' => '',
	'author' => 'Philipp Wrann',
	'author_email' => 'philippwrann@gmail.com',
	'CGLcompliance' => '',
	'CGLcompliance_note' => '',
);

?>