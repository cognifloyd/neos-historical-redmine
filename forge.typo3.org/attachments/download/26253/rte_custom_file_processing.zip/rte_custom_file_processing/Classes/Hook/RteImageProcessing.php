<?php
namespace TYPO3\CMS\RteCustomFileProcessing\Hook;
/***************************************************************
 *  Copyright notice
 *
 *  (c) 2012-2013 Fabien Udriot <fabien.udriot@typo3.org>
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/
use TYPO3\CMS\Core\Html\RteHtmlImageProcessingHookInterface;
use TYPO3\CMS\Core\Resource\File;
use TYPO3\CMS\Core\Resource\ProcessedFile;

/**
 * Implement custom file processing in the context of RTE
 */
class RteImageProcessing implements RteHtmlImageProcessingHookInterface {

	/**
	 * Function to perform a custom file processing in the context of the RTE.
	 *
	 * @param \TYPO3\CMS\Core\Resource\File $file
	 * @param string $fileProcessing
	 * @param array $fileAttributes
	 * @param \TYPO3\CMS\Core\Resource\ProcessedFile $processFile
	 * @return \TYPO3\CMS\Core\Resource\ProcessedFile
	 */
	public function process(File $file, $fileProcessing, array $fileAttributes = array(), \TYPO3\CMS\Core\Resource\ProcessedFile $processFile = NULL) {

		// BEWARE: this code is totally un-secure since data-htmlarea-file-processing must be sanitized for not passing harmful command to the file processor.
		$configuration['additionalParameters'] = $fileAttributes['data-htmlarea-file-processing'];
		$processedFile = $file->process(ProcessedFile::CONTEXT_IMAGECROPSCALEMASK, $configuration);
		return $processedFile;
	}}
