<?php

$GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['t3lib/class.t3lib_parsehtml_proc.php']['RteHtmlImageProcessing'][] =
	'\\TYPO3\\CMS\\RteCustomFileProcessing\\Hook\\RteImageProcessing';
?>