
# Default PAGE object:
page = PAGE
page.10 = TEXT
page.10.value = <h1>Headline</h1>

page.20 = TEXT
page.20.value (
Some longer Text
which might be split across several lines
)
page.20.wrap = <p>|</p>

page.30 = TEXT
page.30.value = <div>Some footer</div>

