<?php

/** @noinspection PhpUndefinedVariableInspection */
\TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
    $_EXTKEY,
    'Flexform',
    'Testing images in flexforms'
);
$TCA['tt_content']['types']['list']['subtypes_addlist']['test_flexform'] = 'pi_flexform';
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPiFlexFormValue('test_flexform', 'FILE:EXT:' . $_EXTKEY . '/Configuration/FlexForms/flexform.xml');