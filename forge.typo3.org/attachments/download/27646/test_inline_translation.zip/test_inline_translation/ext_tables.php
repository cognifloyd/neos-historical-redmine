<?php
if (!defined('TYPO3_MODE')) {
	die('Access denied.');
}

\TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
	$_EXTKEY,
	'Testinlinetranslation',
	'test_inline_translation'
);

if (TYPO3_MODE === 'BE') {

	/**
	 * Registers a Backend Module
	 */
	\TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerModule(
		'Marwein.' . $_EXTKEY,
		'web',	 // Make module a submodule of 'web'
		'inlinetest',	// Submodule key
		'',						// Position
		array(
			'InlineTest' => 'list, show',
			
		),
		array(
			'access' => 'user,group',
			'icon'   => 'EXT:' . $_EXTKEY . '/ext_icon.gif',
			'labels' => 'LLL:EXT:' . $_EXTKEY . '/Resources/Private/Language/locallang_inlinetest.xlf',
		)
	);

}

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addStaticFile($_EXTKEY, 'Configuration/TypoScript', 'test_inline_translation');

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_testinlinetranslation_domain_model_inlinetest', 'EXT:test_inline_translation/Resources/Private/Language/locallang_csh_tx_testinlinetranslation_domain_model_inlinetest.xlf');
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_testinlinetranslation_domain_model_inlinetest');
$GLOBALS['TCA']['tx_testinlinetranslation_domain_model_inlinetest'] = array(
	'ctrl' => array(
		'title'	=> 'LLL:EXT:test_inline_translation/Resources/Private/Language/locallang_db.xlf:tx_testinlinetranslation_domain_model_inlinetest',
		'label' => 'title',
		'tstamp' => 'tstamp',
		'crdate' => 'crdate',
		'cruser_id' => 'cruser_id',
		'dividers2tabs' => TRUE,

		'languageField' => 'sys_language_uid',
		'transOrigPointerField' => 'l10n_parent',
		'transOrigDiffSourceField' => 'l10n_diffsource',
		'delete' => 'deleted',
		'enablecolumns' => array(
			'disabled' => 'hidden',
			'starttime' => 'starttime',
			'endtime' => 'endtime',
		),
		'searchFields' => 'title,fal_property,inline_properties,',
		'dynamicConfigFile' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extPath($_EXTKEY) . 'Configuration/TCA/InlineTest.php',
		'iconfile' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extRelPath($_EXTKEY) . 'Resources/Public/Icons/tx_testinlinetranslation_domain_model_inlinetest.gif'
	),
);

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addLLrefForTCAdescr('tx_testinlinetranslation_domain_model_inlineproperty', 'EXT:test_inline_translation/Resources/Private/Language/locallang_csh_tx_testinlinetranslation_domain_model_inlineproperty.xlf');
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_testinlinetranslation_domain_model_inlineproperty');
$GLOBALS['TCA']['tx_testinlinetranslation_domain_model_inlineproperty'] = array(
	'ctrl' => array(
		'title'	=> 'LLL:EXT:test_inline_translation/Resources/Private/Language/locallang_db.xlf:tx_testinlinetranslation_domain_model_inlineproperty',
		'label' => 'title',
		'tstamp' => 'tstamp',
		'crdate' => 'crdate',
		'cruser_id' => 'cruser_id',
		'dividers2tabs' => TRUE,

		'languageField' => 'sys_language_uid',
		'transOrigPointerField' => 'l10n_parent',
		'transOrigDiffSourceField' => 'l10n_diffsource',
		'delete' => 'deleted',
		'enablecolumns' => array(
			'disabled' => 'hidden',
			'starttime' => 'starttime',
			'endtime' => 'endtime',
		),
		'searchFields' => 'title,',
		'dynamicConfigFile' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extPath($_EXTKEY) . 'Configuration/TCA/InlineProperty.php',
		'iconfile' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extRelPath($_EXTKEY) . 'Resources/Public/Icons/tx_testinlinetranslation_domain_model_inlineproperty.gif'
	),
);
