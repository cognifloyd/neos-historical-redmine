<?php
if (!defined('TYPO3_MODE')) {
	die('Access denied.');
}

\TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
	'Marwein.' . $_EXTKEY,
	'Testinlinetranslation',
	array(
		'InlineTest' => 'list, show',
		
	),
	// non-cacheable actions
	array(
		'InlineTest' => 'list, show',
		
	)
);
