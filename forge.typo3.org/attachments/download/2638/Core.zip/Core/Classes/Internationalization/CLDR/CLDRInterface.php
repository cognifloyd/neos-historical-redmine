<?php
declare(ENCODING = 'utf-8');
namespace F3\Core\Internationalization\CLDR;

/*                                                                        *
 * This script belongs to the FLOW3 framework.                            *
 *                                                                        *
 * It is free software; you can redistribute it and/or modify it under    *
 * the terms of the GNU Lesser General Public License as published by the *
 * Free Software Foundation, either version 3 of the License, or (at your *
 * option) any later version.                                             *
 *                                                                        *
 * This script is distributed in the hope that it will be useful, but     *
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHAN-    *
 * TABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser       *
 * General Public License for more details.                               *
 *                                                                        *
 * You should have received a copy of the GNU Lesser General Public       *
 * License along with the script.                                         *
 * If not, see http://www.gnu.org/licenses/lgpl.html                      *
 *                                                                        *
 * The TYPO3 project - inspiring people to share!                         *
 *                                                                        */

/**
 * An interface for a CLDR object
 *
 * @version $Id:F3\FLOW3\Package\.php 203 2007-03-30 13:17:37Z robert $
 * @license http://www.gnu.org/licenses/lgpl.html GNU Lesser General Public License, version 3 or later
 * @author Arno Dudek <webmaster@adgrafik.at>
 */
interface CLDRInterface {

	/**
	 * Initializion
	 *
	 * @return void
	 * @author Arno Dudek <webmaster@adgrafik.at>
	 */
	public function initializeObject();

	/**
	 * Loads CLDR file
	 *
	 * @param string $sourcePathname
	 * @author Arno Dudek <webmaster@adgrafik.at>
	 */
	public function readCLDRFile($sourcePathname);

	/**
	 * Getter for version
	 *
	 * @return string
	 */
	public function getVersion();

	/**
	 * Getter for generation
	 *
	 * @return string
	 */
	public function getGeneration();

	/**
	 * Default find function
	 *
	 * @return array Returns an array of \SimpleXMLElement objects or FALSE in case of an error.
	 */
	public function find($path);

}
?>