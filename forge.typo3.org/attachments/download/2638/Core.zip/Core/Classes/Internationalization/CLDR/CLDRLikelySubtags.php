<?php
declare(ENCODING = 'utf-8');
namespace F3\Core\Internationalization\CLDR;

/*                                                                        *
 * This script belongs to the FLOW3 framework.                            *
 *                                                                        *
 * It is free software; you can redistribute it and/or modify it under    *
 * the terms of the GNU Lesser General Public License as published by the *
 * Free Software Foundation, either version 3 of the License, or (at your *
 * option) any later version.                                             *
 *                                                                        *
 * This script is distributed in the hope that it will be useful, but     *
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHAN-    *
 * TABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser       *
 * General Public License for more details.                               *
 *                                                                        *
 * You should have received a copy of the GNU Lesser General Public       *
 * License along with the script.                                         *
 * If not, see http://www.gnu.org/licenses/lgpl.html                      *
 *                                                                        *
 * The TYPO3 project - inspiring people to share!                         *
 *                                                                        */

/**
 * Data model for the CLDR supplemental data file
 *
 * @license http://www.gnu.org/licenses/lgpl.html GNU Lesser General Public License, version 3 or later
 * @author Arno Dudek <webmaster@adgrafik.at>
 * @scope singleton
 */
class CLDRLikelySubtags extends \F3\Core\Internationalization\CLDR\AbstractCLDR {

	/**
	 * Relative pathname to the XML source file
	 */
	protected $sourcePathname = 'Resources/Private/Locale/CLDR/Sources/supplemental/likelySubtags.xml';

	/**
	 * Search for all likely subtag of /supplementalData/likelySubtags.
	 *
	 * @return array Returns an array of \SimpleXMLElement objects of found locale identifiers or FALSE in case of an error.
	 */
	public function findAllLikelySubtags() {
		return $this->find('/supplementalData/likelySubtags');
	}

	/**
	 * Find locale identifier specified by language of /supplementalData/likelySubtags.
	 *
	 * @param string $language
	 * @return string Returns found locale identifier else NULL.
	 */
	public function findLikelySubtag($language) {
		$result = $this->find('/supplementalData/likelySubtags/likelySubtag[@from="' . strtolower($language) . '"]');
		return $result ? (string) $result[0]['to'] : NULL;
	}

	/**
	 * Find locale identifier info specified by language of /supplementalData/likelySubtags.
	 * Returns an array with language, script, region and variants.
	 *
	 * @param string $language The language
	 * @param string $script The script
	 * @param string $region The region
	 * @return array Returns locale identifier info or NULL
	 */
	public function findLikelySubtagInfo($language, $script = '', $region = '') {
		$result = $this->findLikelySubtag($language);
		if ($result) {
			list($language, $script, $region) = explode('_', $result);
			return array(
				'language' => $language,
				'script' => $script,
				'region' => $region,
				'variants' => array()
			);
		}
		return NULL;
	}
}
?>