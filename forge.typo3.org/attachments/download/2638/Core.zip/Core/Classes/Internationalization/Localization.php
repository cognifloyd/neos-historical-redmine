<?php
declare(ENCODING = 'utf-8');
namespace F3\Core\Internationalization;

/*                                                                        *
 * This script belongs to the FLOW3 framework.                            *
 *                                                                        *
 * It is free software; you can redistribute it and/or modify it under    *
 * the terms of the GNU Lesser General Public License as published by the *
 * Free Software Foundation, either version 3 of the License, or (at your *
 * option) any later version.                                             *
 *                                                                        *
 * This script is distributed in the hope that it will be useful, but     *
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHAN-    *
 * TABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser       *
 * General Public License for more details.                               *
 *                                                                        *
 * You should have received a copy of the GNU Lesser General Public       *
 * License along with the script.                                         *
 * If not, see http://www.gnu.org/licenses/lgpl.html                      *
 *                                                                        *
 * The TYPO3 project - inspiring people to share!                         *
 *                                                                        */

/**
 * Localization class
 *
 * @version $Id: $
 * @license http://www.gnu.org/licenses/lgpl.html GNU Lesser General Public License, version 3 or later
 * @author Arno Dudek <webmaster@adgrafik.at>
 * @scope singleton
 */
class Localization {

	/**
	 * @var \F3\FLOW3\Object\ObjectManagerInterface
	 */
	protected $objectManager;

	/**
	 * @var \F3\FLOW3\Object\ObjectFactoryInterface
	 */
	protected $objectFactory;

	/**
	 * @var \F3\FLOW3\Configuration\ConfigurationManager
	 */
	protected $configurationManager;

	/**
	 * @var \F3\FLOW3\Session\SessionInterface
	 */
	protected $session;

	/**
	 * @var array
	 */
	protected $settings;

	/**
	 * @var \F3\Core\Internationalization\Locale
	 */
	protected $defaultLocale;

	/**
	 * @var \F3\Core\Internationalization\Locale
	 */
	protected $currentLocale;

	/**
	 * @var \SplObjectStorage
	 */
	protected $localeFallbackOrder;

	/**
	 * Injects the object manager
	 *
	 * @param \F3\FLOW3\Object\ObjectManagerInterface $objectManager A reference to the object manager
	 * @return void
	 */
	public function injectObjectManager(\F3\FLOW3\Object\ObjectManagerInterface $objectManager) {
		$this->objectManager = $objectManager;
	}

	/**
	 * Injects the object factory
	 *
	 * @param \F3\FLOW3\Object\ObjectFactoryInterface $objectFactory A reference to the object factory
	 * @return void
	 */
	public function injectObjectFactory(\F3\FLOW3\Object\ObjectFactoryInterface $objectFactory) {
		$this->objectFactory = $objectFactory;
	}

	/**
	 * Injects the configuration manager
	 *
	 * @param \F3\FLOW3\Configuration\ConfigurationManager $configurationManager A reference to the configuration manager
	 * @return void
	 */
	public function injectConfigurationManager(\F3\FLOW3\Configuration\ConfigurationManager $configurationManager) {
		$this->configurationManager = $configurationManager;
	}

	/**
	 * Injects the session
	 *
	 * @param \F3\FLOW3\Session\SessionInterface $session
	 * @return void
	 */
	public function injectSession(\F3\FLOW3\Session\SessionInterface $session) {
		$this->session = $session;
	}

	/**
	 * Initializion
	 *
	 * @return void
	 * @author Arno Dudek <webmaster@adgrafik.at>
	 */
	public function initializeObject() {
		$settings = $this->configurationManager->getConfiguration(\F3\FLOW3\Configuration\ConfigurationManager::CONFIGURATION_TYPE_SETTINGS, 'Core');
		$this->settings = $settings['localization'];
		$settings = $this->configurationManager->getConfiguration(\F3\FLOW3\Configuration\ConfigurationManager::CONFIGURATION_TYPE_SETTINGS, 'FLOW3');
		$this->defaultLocale = $this->objectFactory->create('F3\Core\Internationalization\Locale', isset($settings['locale']['defaultLocaleIdentifier']) ? $settings['locale']['defaultLocaleIdentifier'] : 'en_Latn_US', FALSE);
		if ($this->session->hasKey('LocalizationCurrentLocale')) $this->currentLocale = $this->session->getData('LocalizationCurrentLocale');
		$this->localeFallbackOrder = $this->buildFallbackOrder();
	}

	/**
	 * This function sets the fallback order in what the localizeable strings will be parsed.
	 * The order comes from the browsers enviroment 'HTTP_ACCEPT_LANGUAGE' if acceptLoclaeFallback is enabled.
	 *
	 * @return void
	 * @author Arno Dudek <webmaster@adgrafik.at>
	 */
	protected function buildFallbackOrder() {
		$fallbackOrder = new \SplObjectStorage();
		// Set current locale allways first if set and valid.
		if ($this->currentLocale !== NULL && $this->currentLocale->isValid()) {
			$this->session->setData('LocalizationCurrentLocale', $this->currentLocale);
			$fallbackOrder->attach($this->currentLocale);
		}

		// Get fall back order of settings
		$fallbackOrderSettings = new \SplObjectStorage();
		foreach ($this->settings['fallbackOrder'] as $localeIdentifier) {
			$locale = $this->objectFactory->create('F3\Core\Internationalization\Locale', $localeIdentifier, FALSE);
			if ($locale->isValid()) $fallbackOrderSettings->attach($locale);
		}

		if ($this->settings['acceptLoclaeFallback']['enable'] === TRUE) {
			$acceptFallbackOrder = $this->buildAcceptLoclaeOrder();
			if ($this->settings['acceptLoclaeFallback']['afterFallbackOrder'] === TRUE) {
				$fallbackOrder->addAll($fallbackOrderSettings);
				$fallbackOrder->addAll($acceptFallbackOrder);
			} else {
				$fallbackOrder->addAll($acceptFallbackOrder);
				$fallbackOrder->addAll($fallbackOrderSettings);
			}
		}

		// Attach default locale at least.
		if ($this->defaultLocale->isValid()) $fallbackOrderSettings->attach($this->defaultLocale);

		// @todo Remove double entries?

		return $fallbackOrder;
	}

	/**
	 * This function returns the language order comes from the enviroment variable 'HTTP_ACCEPT_LANGUAGE'.
	 *
	 * @return array
	 * @author Arno Dudek <webmaster@adgrafik.at>
	 */
	public function buildAcceptLoclaeOrder() {
		$acceptLoclae = new \SplObjectStorage();;
		$httpAcceptLanguage = $this->objectManager->getObject('F3\FLOW3\Utility\Environment')->getHTTPAcceptLanguage();
		$httpAcceptLanguage = str_replace('-', '_', $httpAcceptLanguage); // de-DE = de_DE
		$acceptLanguages = explode(',', $httpAcceptLanguage);
		foreach ($acceptLanguages as $language) {
			list($languageIdentifier, ) = explode(';', $language);
			$locale = $this->objectFactory->create('F3\Core\Internationalization\Locale', $languageIdentifier, FALSE);
			if ($locale->isValid()) $acceptLoclae->attach($locale);
		}
		return $acceptLoclae;
	}

	/**
	 * Sets the currently active language and rebuild the language fallback order.
	 *
	 * @param \F3\Core\Internationalization\Locale $locale
	 * @return void
	 * @author Arno Dudek <webmaster@adgrafik.at>
	 */
	public function setCurrentLocale(\F3\Core\Internationalization\Locale $locale) {
		$this->currentLocale = $locale;
		$this->buildFallbackOrder();
	}

	/**
	 * Gets the currently active language.
	 *
	 * @return \F3\Core\Internationalization\Locale
	 * @author Arno Dudek <webmaster@adgrafik.at>
	 */
	public function getCurrentLocale() {
		return $this->currentLocale;
	}

	/**
	 * Gets the locale fallback order.
	 *
	 * @return \SplObjectStorage
	 * @author Arno Dudek <webmaster@adgrafik.at>
	 */
	public function getLocaleFallbackOrder() {
		return $this->localeFallbackOrder;
	}
}

?>