<?php
declare(ENCODING = 'utf-8');
namespace F3\Core\Internationalization;

/*                                                                        *
 * This script belongs to the FLOW3 framework.                            *
 *                                                                        *
 * It is free software; you can redistribute it and/or modify it under    *
 * the terms of the GNU Lesser General Public License as published by the *
 * Free Software Foundation, either version 3 of the License, or (at your *
 * option) any later version.                                             *
 *                                                                        *
 * This script is distributed in the hope that it will be useful, but     *
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHAN-    *
 * TABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser       *
 * General Public License for more details.                               *
 *                                                                        *
 * You should have received a copy of the GNU Lesser General Public       *
 * License along with the script.                                         *
 * If not, see http://www.gnu.org/licenses/lgpl.html                      *
 *                                                                        *
 * The TYPO3 project - inspiring people to share!                         *
 *                                                                        */

/**
 * String localization class
 *
 * = Examples =
 *
 * <code title="Localized string (e.g. in the YAML-file Standard/en_US/LocalizedStrings.yaml)">
 * exampleString1: 'Firstname:'
 * exampleString2:
 *   1: 'My %sst %s String for {split: Me, You}'
 *   2: 'My %snd %s String for {split: Me, You}'
 *   4: 'My %sth %s String for {split: Me, You}'
 * </code>
 * <code title="Example 1">
 * $stringLocalization->getLocalizedString('exampleString1') . 'A name';
 * </code>
 * <output>
 * Firstname: A name
 * </output>
 *
 * </code>
 * <code title="Example 2: Replace strings, Plurals and split options">
 * '1: ' . $stringLocalization->getLocalizedString('exampleString2', 'AnotherPackage', 'AnotherController', array(1, 'replaced'), 1, 0);
 * '2: ' . $stringLocalization->getLocalizedString('exampleString2', 'AnotherPackage', 'AnotherController', array(2, 'replaced'), 2, 1);
 * '3: ' . $stringLocalization->getLocalizedString('exampleString2', 'AnotherPackage', 'AnotherController', array(3, 'replaced'), 3, 0);
 * '4: ' . $stringLocalization->getLocalizedString('exampleString2', 'AnotherPackage', 'AnotherController', array(4, 'replaced'), 4, 1);
 * '5: ' . $stringLocalization->getLocalizedString('exampleString2', 'AnotherPackage', 'AnotherController', array(5, 'replaced'), 5, 0);
 * </code>
 * <output>
 * 1: My 1st replaced String for Me
 * 2: My 2nd replaced String for You
 * 3: My 3nd replaced String for Me   // Here you can see "3nd" cause this is missing in the language file.
 * 4: My 4th replaced String for You
 * 5: My 5th replaced String for Me  // Plural values greater than or equal to the current value takes the last matching.
 * </output>
 *
 * @version $Id: $
 * @license http://www.gnu.org/licenses/lgpl.html GNU Lesser General Public License, version 3 or later
 * @author Arno Dudek <webmaster@adgrafik.at>
 * @scope singleton
 */
class StringLocalization {

	/**
	 * This regular expression scans if the localized string has split values
	 *
	 * @author Arno Dudek <webmaster@adgrafik.at>
	 */
	public static $SCAN_PATTERN_SPLITVALUES = '/{split:(.[^}]*)}/i';

	/**
	 * @var \F3\FLOW3\Object\ObjectManagerInterface
	 */
	protected $objectManager;

	/**
	 * @var \F3\FLOW3\Object\ObjectFactoryInterface
	 */
	protected $objectFactory;

	/**
	 * @var \F3\FLOW3\Package\PackageManagerInterface
	 */
	protected $packageManager;

	/**
	 * @var \F3\FLOW3\Configuration\ConfigurationManager
	 */
	protected $configurationManager;

	/**
	 * @var array
	 */
	protected $settings;

	/**
	 * @var string
	 */
	protected $packageName;

	/**
	 * @var string
	 */
	protected $subPackageName;

	/**
	 * @var string
	 */
	protected $controllerName;

	/**
	 * @var \F3\Core\Internationalization\Localization
	 */
	protected $localization;

	/**
	 * @var string
	 */
	protected $languageResourcePath;

	/**
	 * @var array
	 */
	protected $localizedStrings;

	/**
	 * Injects the object manager
	 *
	 * @param \F3\FLOW3\Object\ObjectManagerInterface $objectManager A reference to the object manager
	 * @return void
	 */
	public function injectObjectManager(\F3\FLOW3\Object\ObjectManagerInterface $objectManager) {
		$this->objectManager = $objectManager;
	}

	/**
	 * Injects the object factory
	 *
	 * @param \F3\FLOW3\Object\ObjectFactoryInterface $objectFactory A reference to the object factory
	 * @return void
	 */
	public function injectObjectFactory(\F3\FLOW3\Object\ObjectFactoryInterface $objectFactory) {
		$this->objectFactory = $objectFactory;
	}

	/**
	 * Injects the package manager
	 *
	 * @param \F3\FLOW3\Package\PackageManagerInterface $packageManager A reference to the package manager
	 * @return void
	 */
	public function injectPackageManager(\F3\FLOW3\Package\PackageManagerInterface $packageManager) {
		$this->packageManager = $packageManager;
	}

	/**
	 * Injects the configuration manager
	 *
	 * @param \F3\FLOW3\Configuration\ConfigurationManager $configurationManager A reference to the configuration manager
	 * @return void
	 */
	public function injectConfigurationManager(\F3\FLOW3\Configuration\ConfigurationManager $configurationManager) {
		$this->configurationManager = $configurationManager;
	}

	/**
	 * Injects the localization
	 *
	 * @param \F3\Core\Internationalization\Localization $localization A reference to the localization
	 * @return void
	 */
	public function injectLocalization(\F3\Core\Internationalization\Localization $localization) {
		$this->localization = $localization;
	}

	/**
	 * Initializion
	 *
	 * @return void
	 * @author Arno Dudek <webmaster@adgrafik.at>
	 */
	public function initializeObject() {
		$settings = $this->configurationManager->getConfiguration(\F3\FLOW3\Configuration\ConfigurationManager::CONFIGURATION_TYPE_SETTINGS, 'Core');
		$this->settings = $settings['stringLocalization'];
		$this->languageResourcePath = 'Resources/Private/Languages/';
		$this->localizedStrings = array();
	}

	/**
	 * Function to get a localized string
	 * Steps through the locale fallback order until match language is found
	 *
	 * @param string $key The key from the $languageRepository for which to return the value.
	 * @param string $packageName The name of the package
	 * @param string $subPackageName The name of the sub package
	 * @param string $controllerName The name of the controller
	 * @param array $replaceStrings the arguments of the extension, being passed over to vsprintf
	 * @param integer $pluralValue
	 * @param integer $splitKey
	 * @param string $defaultValue Default value
	 * @param boolean $htmlEscape TRUE if the result should be htmlescaped.
	 * @return string The value from $localizedStrings or NULL if no translation was found.
	 * @throws \InvalidArgumentException if the language key is not a string
	 * @author Arno Dudek <webmaster@adgrafik.at>
	 */
	public function getLocalizedString($key, $packageName, $subPackageName = NULL, $controllerName = 'Standard', array $replaceStrings = NULL, $pluralValue = NULL, $splitKey = NULL, $defaultValue = NULL, $htmlEscape = NULL) {
		if (!is_string($key)) throw new \InvalidArgumentException('The language key must be of type string, ' . gettype($key) . ' given.', 1267790268);
		$resourcePath = $this->packageManager->getPackage($packageName)->getPackagePath() . $this->languageResourcePath;
		$value = NULL;

		$localeFallbackOrder = $this->localization->getLocaleFallbackOrder();
		foreach ($localeFallbackOrder as $locale) {
			$languageIdentifier = $locale->getLanguageIdentifier();
			$packageIdentifier = md5($languageIdentifier, $packageName . $subPackageName . $controllerName);

			if (!isset($this->localizedStrings[$packageIdentifier][$key])) {
				$this->loadLanguageFile($packageName, $subPackageName, $controllerName, $locale);
			}

			// Try again
			if (isset($this->localizedStrings[$packageIdentifier][$key])) {
				$localizableString = $this->localizedStrings[$packageIdentifier][$key];
				break;
			}
		}

		// Get plural key
		if (isset($localizableString)) {
			if ($pluralValue === NULL && is_array($localizableString)) {
				$value = current($localizableString);
			} elseif ($pluralValue !== NULL && is_array($localizableString)) {
				ksort($localizableString);
				foreach ($localizableString as $pluralKey => $string) {
					$value = $string;
					if ($pluralKey >= $pluralValue) break;
				}
			} else {
				$value = $localizableString;
			}
		}

		//  If $value and $defaultValue are NULL escape and replace is not nessessary
		if ($value === NULL) {
			if ($defaultValue === NULL) {
				return;
			} else {
				$value = $defaultValue;
			}
		}

		// Parse split option value
		if ($splitKey !== NULL) {
			preg_match_all(self::$SCAN_PATTERN_SPLITVALUES, $value, $splitOptions);
			foreach ($splitOptions[1] as $key => $splitOption) {
				$split = explode(',', $splitOption);
				$splitValue = isset($split[$splitKey]) ? $split[$splitKey] : $split[0];
				$value = str_replace($splitOptions[0][$key], trim($splitValue), $value);
			}
		}

		// Do HTML escape before replace strings.
		$value = ($htmlEscape || ($htmlEscape === NULL && $this->settings['defaults']['htmlEscape'])) ? htmlspecialchars($value) : $value;

		if ($replaceStrings !== NULL) {
			// Set single replace string to counting array
			if (isset($replaceStrings['key'])) {
				$replaceStrings = array($replaceStrings);
			}
			// Render replace strings
			foreach ($replaceStrings as &$replaceString) {
				$renderKey = isset($replaceString['key']) ? $replaceString['key'] : NULL;  // Delegate missing error to render function
				$renderPackageName = isset($replaceString['packageName']) ? $replaceString['packageName'] : $packageName;
				$renderSubPackageName = isset($replaceString['subPackageName']) ? $replaceString['subPackageName'] : $subPackageName;
				$renderControllerName = isset($replaceString['controllerName']) ? $replaceString['controllerName'] : $controllerName;
				$renderReplaceStrings = isset($replaceString['replaceStrings']) ? $replaceString['replaceStrings'] : NULL;
				$renderPluralValue = isset($replaceString['pluralValue']) ? $replaceString['pluralValue'] : NULL;
				$renderSplitKey = isset($replaceString['splitKey']) ? $replaceString['splitKey'] : NULL;
				$renderDefaultValue = isset($replaceString['defaultValue']) ? $replaceString['defaultValue'] : NULL;
				$renderHtmlEscape = isset($replaceString['htmlEscape']) ? $replaceString['htmlEscape'] : NULL;
				$replaceString = $this->getLocalizedString($renderKey, $renderPackageName, $renderSubPackageName, $renderControllerName, $renderReplaceStrings, $renderPluralValue, $renderSplitKey, $renderDefaultValue, $renderHtmlEscape);
			}
			$value = vsprintf($value, $replaceString);
		}

		return $value;
	}

	/**
	 * Loads a language file and returns TRUE on success.
	 *
	 * @param string $packageName
	 * @param string $subPackageName
	 * @param string $controllerName
	 * @param \F3\Core\Internationalization\Locale $locale
	 * @return boolean Returns FALSE if loading faild
	 * @throws \F3\Core\Internationalization\Exception\ParseErrorException on parse error while parsing yaml file.
	 * @author Arno Dudek <webmaster@adgrafik.at>
	 */
	public function loadLanguageFile($packageName, $subPackageName, $controllerName, $locale = NULL) {
		if (($localizedStringsResourcePathname = $this->findLocalizedStringsResourcePathname($packageName, $subPackageName, $controllerName, $locale)) === FALSE) {
			return FALSE;
		}

		$packageIdentifier = md5($locale->getLanguageIdentifier(), $packageName . $subPackageName . $controllerName);
		if (!isset($this->localizedStrings[$packageIdentifier])) {
			$this->localizedStrings[$packageIdentifier] = array();
		}

		$pathExtentsion = pathinfo($localizedStringsResourcePathname, PATHINFO_EXTENSION);
		if ($pathExtentsion === 'yaml') {
			try {
				$localizedStrings = \F3\YAML\Yaml::loadFile($localizedStringsResourcePathname);
			} catch (\F3\FLOW3\Error\Exception $exception) {
				throw new \F3\Core\Internationalization\Exception\ParseErrorException('A parse error occurred while parsing file "' . $localizedStringsResourcePathname . '". Error message: ' . $exception->getMessage(), 1267884418);
			}

			$this->localizedStrings[$packageIdentifier] =
				\F3\FLOW3\Utility\Arrays::arrayMergeRecursiveOverrule($this->localizedStrings[$packageIdentifier], $localizedStrings);
		} else {
			$localizedStrings = array();
			if (($source = simplexml_load_file($localizedStringsResourcePathname)->xpath('//label')) === FALSE) {
				return FALSE;
			}
			foreach ($source as $value) {
				$this->localizedStrings[$packageIdentifier][(string) $value['index']] = (string) $value;
			}
		}

		return TRUE;
	}

	/**
	 * Finds the next matching localized strings file.
	 * Fallback order of directory search:
	 * PathToLanguageResourceDir/PackageName/(SubPackageName)/ControllerName/LanguageIdentifier
	 * PathToLanguageResourceDir/PackageName/(SubPackageName)/ControllerName/NextMatchLanguageIdentifier
	 * PathToLanguageResourceDir/PackageName/(SubPackageName)/StandardControllerName/LanguageIdentifier
	 * PathToLanguageResourceDir/PackageName/(SubPackageName)/StandardControllerName/NextMatchLanguageIdentifier
	 * Fallback order of file search:
	 * LocalizedStringsControllerName.yaml
	 * LocalizedStringsControllerName.xml
	 * LocalizedStringsStandardControllerName.yaml
	 * LocalizedStringsStandardControllerName.xml
	 *
	 * @param string $packageName
	 * @param string $subPackageName
	 * @param string $controllerName
	 * @param \F3\Core\Internationalization\Locale $locale
	 * @return mixed Returns FALSE if no file found, else the localized strings resource pathname
	 * @author Arno Dudek <webmaster@adgrafik.at>
	 */
	protected function findLocalizedStringsResourcePathname($packageName, $subPackageName = NULL, $controllerName = 'Standard', $locale = NULL) {
		if ($locale === NULL) {
			$localeFallbackOrder = $this->localization->getLocaleFallbackOrder();
			$result = FALSE;
			foreach ($localeFallbackOrder as $locale) {
				if (($result = $this->findLocalizedStringsResourcePathname($packageName, $subPackageName, $controllerName, $locale)) !== FALSE) {
					break;
				}
			}
			return $result;
		}

		$basePath = \F3\FLOW3\Utility\Files::concatenatePaths(array($this->packageManager->getPackage($packageName)->getPackagePath(), $this->languageResourcePath));
		$languageIdentifier = $locale->getLanguageIdentifier();
		$localizedStringsResourcePath = \F3\FLOW3\Utility\Files::concatenatePaths(array($basePath, $subPackageName, $controllerName, $languageIdentifier));
		if (!@is_dir($localizedStringsResourcePath)) {
			$nextMatchLanguageIdentifier = $locale->getNextMatchLanguageIdentifier();
			$localizedStringsResourcePath = \F3\FLOW3\Utility\Files::concatenatePaths(array($basePath, $subPackageName, $controllerName, $nextMatchLanguageIdentifier));
			if (!@is_dir($localizedStringsResourcePath)) {
				if ($controllerName !== 'Standard') {
					$localizedStringsResourcePath = \F3\FLOW3\Utility\Files::concatenatePaths(array($basePath, $subPackageName, 'Standard', $languageIdentifier));
					if (!@is_dir($localizedStringsResourcePath)) {
						$localizedStringsResourcePath = \F3\FLOW3\Utility\Files::concatenatePaths(array($basePath, $subPackageName, 'Standard', $nextMatchLanguageIdentifier));
						if (!@is_dir($localizedStringsResourcePath)) {
							return FALSE;
						}
					}
				} else return FALSE;
			}
		}
		$localizedStringsResourcePathname = \F3\FLOW3\Utility\Files::concatenatePaths(array($localizedStringsResourcePath, 'LocalizedStrings.yaml'));
		if (!@is_file($localizedStringsResourcePathname)) {
			$localizedStringsResourcePathname = \F3\FLOW3\Utility\Files::concatenatePaths(array($localizedStringsResourcePath, 'LocalizedStrings.xml'));
			if (!@is_file($localizedStringsResourcePathname)) {
				return FALSE;
			}
		}
		return $localizedStringsResourcePathname;
	}

	/**
	 * Short alias of get() which use the context.
	 *
	 * @param string $key The key from the $languageRepository for which to return the value.
	 * @param array $replaceStrings the arguments of the extension, being passed over to vsprintf
	 * @param integer $pluralValue
	 * @param integer $splitKey
	 * @param string $defaultValue Default value
	 * @param boolean $htmlEscape TRUE if the result should be htmlescaped. This won't have an effect for the default value
	 * @return string The value from $localizedStrings or NULL if no translation was found.
	 * @throws \F3\Core\Internationalization\Exception\NoStringLocalizationContextSetException if no string localization context is set.
	 * @author Arno Dudek <webmaster@adgrafik.at>
	 */
	public function get($key, array $replaceStrings = NULL, $pluralValue = NULL, $splitKey = NULL, $defaultValue = NULL, $htmlEscape = NULL) {
		if ($this->packageName === NULL) throw new \F3\Core\Internationalization\Exception\NoStringLocalizationContextSetException('No string localization context is set. Key ' . $key . ' given.', 1267789740);
		$this->getLocalizedString($key, $this->packageName, $this->controllerName, $replaceStrings, $pluralValue, $splitKey, $defaultValue, $htmlEscape);
	}

	/**
	 * Sets the context.
	 *
	 * @param string $packageName
	 * @param string $subPackageName
	 * @param string $controllerName
	 * @author Arno Dudek <webmaster@adgrafik.at>
	 */
	public function setContext($packageName, $subPackageName = NULL, $controllerName = 'Standard') {
		$this->packageName = $packageName;
		$this->subPackageName = $subPackageName;
		$this->controllerName = $controllerName;
	}
}

?>