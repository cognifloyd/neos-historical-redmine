<?php
declare(ENCODING = 'utf-8');
namespace F3\Core\Internationalization\CLDR;

/*                                                                        *
 * This script belongs to the FLOW3 framework.                            *
 *                                                                        *
 * It is free software; you can redistribute it and/or modify it under    *
 * the terms of the GNU Lesser General Public License as published by the *
 * Free Software Foundation, either version 3 of the License, or (at your *
 * option) any later version.                                             *
 *                                                                        *
 * This script is distributed in the hope that it will be useful, but     *
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHAN-    *
 * TABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser       *
 * General Public License for more details.                               *
 *                                                                        *
 * You should have received a copy of the GNU Lesser General Public       *
 * License along with the script.                                         *
 * If not, see http://www.gnu.org/licenses/lgpl.html                      *
 *                                                                        *
 * The TYPO3 project - inspiring people to share!                         *
 *                                                                        */

/**
 * The CLDR reader class
 *
 * @license http://www.gnu.org/licenses/lgpl.html GNU Lesser General Public License, version 3 or later
 * @scope singleton
 */
class CLDRReader {

	/**
	 * @var \F3\FLOW3\Object\ObjectManagerInterface
	 */
	protected $objectManager;

	/**
	 * Package CLDR data constructor
	 *
	 * @param \F3\FLOW3\Object\ObjectManagerInterface $objectManager
	 * @param \F3\FLOW3\Cache\CacheManager $cacheManager
	 * @author Arno Dudek <webmaster@adgrafik.at>
	 */
	public function __construct(\F3\FLOW3\Object\ObjectManagerInterface $objectManager, \F3\FLOW3\Cache\CacheManager $cacheManager) {
		$this->objectManager = $objectManager;
	}

	/**
	 * Returns CLDRInterface
	 *
	 * @return \F3\Core\Internationalization\CLDR\CLDRInterface The result of the get method
	 * @author Arno Dudek <webmaster@adgrafik.at>
	 */
	public function loadRepository($cldrRepositoryName) {
		return $this->objectManager->getObject('F3\Core\Internationalization\CLDR\CLDR' . $cldrRepositoryName);
	}

	/**
	 * Magic call method for getting CLDR data repository.
	 *
	 * Currently provides two methods
	 *  - get<SupplementalDataKey>($value, $caseSensitive = TRUE)
	 *
	 * @param string $methodName Name of the method
	 * @param array $arguments The arguments
	 * @return \F3\Core\Internationalization\CLDR\CLDRInterface The result of the get method
	 * @author Arno Dudek <webmaster@adgrafik.at>
	 */
	public function __call($methodName, array $arguments) {
		if (substr($methodName, 0, 4) === 'load' && strlen($methodName) > 5) {
			$className = substr($methodName, 4);
			return $this->loadRepository($className);
		}
		trigger_error('Call to undefined method ' . get_class($this) . '::' . $methodName, E_USER_ERROR);
	}

}
?>