<?php
declare(ENCODING = 'utf-8');
namespace F3\Core\Internationalization\CLDR;

/*                                                                        *
 * This script belongs to the FLOW3 framework.                            *
 *                                                                        *
 * It is free software; you can redistribute it and/or modify it under    *
 * the terms of the GNU Lesser General Public License as published by the *
 * Free Software Foundation, either version 3 of the License, or (at your *
 * option) any later version.                                             *
 *                                                                        *
 * This script is distributed in the hope that it will be useful, but     *
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHAN-    *
 * TABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser       *
 * General Public License for more details.                               *
 *                                                                        *
 * You should have received a copy of the GNU Lesser General Public       *
 * License along with the script.                                         *
 * If not, see http://www.gnu.org/licenses/lgpl.html                      *
 *                                                                        *
 * The TYPO3 project - inspiring people to share!                         *
 *                                                                        */

/**
 * Data model for the CLDR supplemental data file
 *
 * @license http://www.gnu.org/licenses/lgpl.html GNU Lesser General Public License, version 3 or later
 * @author Arno Dudek <webmaster@adgrafik.at>
 * @scope singleton
 */
class CLDRSupplementalData extends \F3\Core\Internationalization\CLDR\AbstractCLDR {

	/**
	 * Relative pathname to the XML source file
	 */
	protected $sourcePathname = 'Resources/Private/Locale/CLDR/Sources/supplemental/supplementalData.xml';

	/**
	 * Search for all language items of /supplementalData/languageData.
	 *
	 * @return array Returns an array of \SimpleXMLElement objects of all language items of /supplementalData/languageData or FALSE in case of an error.
	 * @author Arno Dudek <webmaster@adgrafik.at>
	 */
	public function findAllLanguageData() {
		return $this->find('/supplementalData/languageData');
	}

	/**
	 * Search for language item of /supplementalData/languageData by given language.
	 *
	 * @param string $language
	 * @return array Returns an array of \SimpleXMLElement objects of all language items of /supplementalData/languageData by given language or FALSE in case of an error.
	 * @author Arno Dudek <webmaster@adgrafik.at>
	 */
	public function findLanguageDataByLaguage($language) {
		return $this->find('/supplementalData/languageData/language[@type="' . strtolower($language) . '"]');
	}

	/**
	 * Search for all language items of /supplementalData/languageData by given language, script and region.
	 *
	 * @param string $language The language
	 * @param string $script The script
	 * @param string $region The region
	 * @return array Returns an array of \SimpleXMLElement objects of found language data or FALSE in case of an error.
	 * @author Arno Dudek <webmaster@adgrafik.at>
	 */
	public function findRelatedLanguageData($language, $script = '', $region = '') {
		return $this->find('/supplementalData/languageData/language[@type="' . $language . '" and (contains(@scripts, "' . $script . '") or contains(@territories, "' . $region . '"))]');
	}
}
?>