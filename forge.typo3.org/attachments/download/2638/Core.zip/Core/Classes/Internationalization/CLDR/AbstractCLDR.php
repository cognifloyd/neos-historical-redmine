<?php
declare(ENCODING = 'utf-8');
namespace F3\Core\Internationalization\CLDR;

/*                                                                        *
 * This script belongs to the FLOW3 framework.                            *
 *                                                                        *
 * It is free software; you can redistribute it and/or modify it under    *
 * the terms of the GNU Lesser General Public License as published by the *
 * Free Software Foundation, either version 3 of the License, or (at your *
 * option) any later version.                                             *
 *                                                                        *
 * This script is distributed in the hope that it will be useful, but     *
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHAN-    *
 * TABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser       *
 * General Public License for more details.                               *
 *                                                                        *
 * You should have received a copy of the GNU Lesser General Public       *
 * License along with the script.                                         *
 * If not, see http://www.gnu.org/licenses/lgpl.html                      *
 *                                                                        *
 * The TYPO3 project - inspiring people to share!                         *
 *                                                                        */

/**
 * Data model for a CLDR file
 *
 * @license http://www.gnu.org/licenses/lgpl.html GNU Lesser General Public License, version 3 or later
 * @author Arno Dudek <webmaster@adgrafik.at>
 * @scope singleton
 */
abstract class AbstractCLDR implements \F3\Core\Internationalization\CLDR\CLDRInterface {

	/**
	 * Relative pathname to the XML source file
	 */
	protected $sourcePathname;

	/**
	 * @var \SimpleXMLElement
	 */
	protected $dataRepository;

	/**
	 * Initializion
	 *
	 * @return void
	 * @author Arno Dudek <webmaster@adgrafik.at>
	 */
	public function initializeObject() {
		$this->dataRepository = $this->readCLDRFile(\F3\FLOW3\Utility\Files::concatenatePaths(array(FLOW3_PATH_FLOW3, $this->sourcePathname)));
	}

	/**
	 * Loads CLDR file
	 *
	 * @param string $sourcePathname
	 * @author Arno Dudek <webmaster@adgrafik.at>
	 */
	public function readCLDRFile($sourcePathname) {
		return simplexml_load_file($sourcePathname);
	}

	/**
	 * Getter for version
	 *
	 * @return string
	 */
	public function getVersion() {
		$result = $this->dataRepository->xpath('/ldml/identity/version | /supplementalData/version');
		return count($result) ? (string) $result[0]['version'] : '-';
	}

	/**
	 * Getter for generation
	 *
	 * @return string
	 */
	public function getGeneration() {
		$result = $this->dataRepository->xpath('/ldml/identity/generation | /supplementalData/generation');
		return count($result) ? (string) $result[0]['generation'] : '-';
	}

	/**
	 * Default find function
	 *
	 * @return array Returns an array of \SimpleXMLElement objects or FALSE in case of an error.
	 */
	public function find($path) {
		return $this->dataRepository->xpath($path);
	}
}
?>