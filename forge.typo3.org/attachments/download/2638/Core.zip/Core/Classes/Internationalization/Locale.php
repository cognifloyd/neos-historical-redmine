<?php
declare(ENCODING = 'utf-8');
namespace F3\Core\Internationalization;

/*                                                                        *
 * This script belongs to the FLOW3 framework.                            *
 *                                                                        *
 * It is free software; you can redistribute it and/or modify it under    *
 * the terms of the GNU Lesser General Public License as published by the *
 * Free Software Foundation, either version 3 of the License, or (at your *
 * option) any later version.                                             *
 *                                                                        *
 * This script is distributed in the hope that it will be useful, but     *
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHAN-    *
 * TABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser       *
 * General Public License for more details.                               *
 *                                                                        *
 * You should have received a copy of the GNU Lesser General Public       *
 * License along with the script.                                         *
 * If not, see http://www.gnu.org/licenses/lgpl.html                      *
 *                                                                        *
 * The TYPO3 project - inspiring people to share!                         *
 *                                                                        */

/**
 * Represents a locale
 *
 * Objects of this kind conveniently represent locales usually described by
 * locale identifiers such as de_DE, en_Latin_US etc. The locale identifiers
 * used are defined in the Unicode Technical Standard #35 (Unicode Locale
 * Data Markup Language).
 *
 * Using this class asserts the validity of the used locale and provides you
 * with some useful methods for getting more information about it.
 *
 * @version $Id: Locale.php 3643 2010-01-15 14:38:07Z robert $
 * @license http://www.gnu.org/licenses/lgpl.html GNU Lesser General Public License, version 3 or later
 * @see http://www.unicode.org/reports/tr35/
 * @author Robert Lemke <robert@typo3.org>
 * @author Arno Dudek <webmaster@adgrafik.at>
 * @scope prototype
 */
class Locale {

	/**
	 * Simplified pattern which maches (most) locale identifiers
	 *
	 * @see http://rfc.net/rfc4646.html
	 */
	const PATTERN_MATCH_LOCALEIDENTIFIER = '/^(?P<language>root|[a-z]{2,3})(?:[-_](?P<script>[a-z]{4}))?(?:[-_](?P<region>[a-z]{2}|[0-9]{3}))?(?:[-_](?P<variants>([a-zA-Z0-9]{5,8}|[0-9][a-zA-Z0-9]{3})?(?:[-_])?))?(?:[-_]u[-_](?P<extensions>[a-z0-9-_]*))?$/i';
	const PATTERN_MATCH_LOCALEEXTENSIONS = '/([a-z0-9]{2}(?:[-_][a-z0-9]{3,8})?)/i';

	/**
	 * @var \F3\FLOW3\Object\ObjectManagerInterface
	 */
	protected $objectManager;

	/**
	 * The locale identifier - a BCP47, ISO 639-3 or 639-5 code
	 * Like the standard says, we use "mul" to label multilanguage content
	 *
	 * @var string
	 * @see http://rfc.net/bcp47.html
	 * @see http://en.wikipedia.org/wiki/ISO_639
	 */
	protected $localeIdentifier;

	/**
	 * The language identifier - a BCP47, ISO 639-3 or 639-5 code
	 *
	 * @var string
	 * @see http://rfc.net/bcp47.html
	 * @see http://en.wikipedia.org/wiki/ISO_639
	 */
	protected $language;

	/**
	 * The script identifier - an ISO 15924 code according to BCP47
	 *
	 * @var string
	 * @see http://rfc.net/bcp47.html
	 * @see http://unicode.org/iso15924/iso15924-codes.html
	 * @see http://en.wikipedia.org/wiki/List_of_ISO_15924_codes
	 */
	protected $script;

	/**
	 * The region identifier - an ISO 3166-1-alpha-2 code or a UN M.49 three digit code
	 * Note: We use "ZZ" for "unknown region" or "global"
	 *
	 * @var string
	 * @see http://www.iso.org/iso/country_codes/iso_3166_code_lists.htm
	 * @see http://en.wikipedia.org/wiki/ISO_3166
	 */
	protected $region;

	/**
	 * The optional variant identifier - one of the registered registered variants according to BCP47
	 *
	 * @var array
	 * @see http://rfc.net/bcp47.html
	 */
	protected $variants;

	/**
	 * The optional extensions identifier - one of the registered registered variants according to BCP47
	 *
	 * @var array
	 * @see http://rfc.net/bcp47.html
	 */
	protected $extensions;

	/**
	 * CLDR language alias
	 *
	 * @var array
	 */
	protected static $cldrLanguageAlias;

	/**
	 * Constructs this locale object
	 *
	 * @param string $localeIdentifier A valid locale identifier according to UTS#35
	 * @param string $validate If set TRUE, an exception is thrown if the locale identifier is not valid
	 * @param \F3\FLOW3\Object\ObjectManagerInterface $objectManager
	 * @throws \InvalidArgumentException if the locale identifier is not a string
	 * @throws \F3\Core\Internationalization\Exception\InvalidLocaleIdentifier if the locale identifier is not valid
	 * @author Robert Lemke <robert@typo3.org>
	 * @author Arno Dudek <webmaster@adgrafik.at>
	 */
	public function __construct($localeIdentifier, $validate = TRUE, \F3\FLOW3\Object\ObjectManagerInterface $objectManager) {
		if (!is_string($localeIdentifier)) throw new \InvalidArgumentException('A locale identifier must be of type string, ' . gettype($localeIdentifier) . ' given.', 1221216120);
		$this->objectManager = $objectManager;

		// @see http://www.unicode.org/reports/tr35/#BCP_47_Language_Tag_Conversion
		// Replace the "-" separators with "_"
		$localeIdentifier = str_replace('-', '_', $localeIdentifier); // de-DE = de_DE (There are no "-" in the CLDR ...)
		// Replace the special language identifier "root" with the BCP 47 primary language tag "und"
		if (stripos($localeIdentifier, 'root') === 0) $localeIdentifier = substr_replace($localeIdentifier, 'und', 0, 4); // root_u_cu_usd = und_u_cu_usd
		if (self::$cldrLanguageAlias === NULL) {
			$cldrReader = $this->objectManager->getObject('F3\Core\Internationalization\CLDR\CLDRReader')->loadSupplementalMetadata();
			self::$cldrLanguageAlias = $cldrReader->findAllLanguageAlias();
		}
		// If the BCP 47 primary language subtag matches the type attribute of a languageAlias element in supplementalMetadata.xml,
		// replace the language subtag with the replacement value.
		foreach (self::$cldrLanguageAlias as $alias) {
			if (stripos($localeIdentifier, (string) $alias['type']) === 0) {
				$replacement = explode(' ', (string) $alias['replacement']); // Just take the first one
				$localeIdentifier = substr_replace($localeIdentifier, $replacement[0], 0, strlen((string) $alias['type']));
				break;
			}
		}

		preg_match(self::PATTERN_MATCH_LOCALEIDENTIFIER, $localeIdentifier, $matches);
		$this->localeIdentifier = $localeIdentifier;
		$this->language = isset($matches['language']) ? strtolower($matches['language']) : '';
		$this->script = isset($matches['script']) ? ucfirst($matches['script']) : '';
		$this->region = isset($matches['region']) ? strtoupper($matches['region']) : '';
		$this->variants = isset($matches['variants']) ? explode('_', $matches['variants']) : array();
		if (isset($matches['extensions'])) {
			preg_match_all(self::PATTERN_MATCH_LOCALEEXTENSIONS, $matches['extensions'], $matchesExtensions);
			$this->extensions = isset($matchesExtensions[1]) ? $matchesExtensions[1] : array();
		}

		if ($validate && !$this->isValid()) {
			throw new \F3\Core\Internationalization\Exception\InvalidLocaleIdentifierException('"' . $this->localeIdentifier . '" is not a valid locale identifier.', 1221137814);
		}
	}

	/**
	 * Checks if this locale is valid
	 *
	 * @return boolean Returns true if given locale is valid
	 * @author Arno Dudek <webmaster@adgrafik.at>
	 */
	public function isValid() {
		if (!preg_match('/^[a-z]{2,3}$/', $this->language)) return FALSE;
		if ($this->region && !preg_match('/^([A-Z]{2}|[0-9]{3})$/', $this->region)) return FALSE;
		if ($this->script && !preg_match('/^[A-Z][a-z]{3}$/', $this->script)) return FALSE;

		// If script or region are not set, they are in any case TRUE
		$scriptIsValid = $this->script ? FALSE : TRUE;
		$regionIsValid = $this->region ? FALSE : TRUE;
		$cldrReader = $this->objectManager->getObject('F3\Core\Internationalization\CLDR\CLDRReader')->loadSupplementalData();
		$result = $cldrReader->findRelatedLanguageData($this->language, $this->script, $this->region);
		foreach ($result as $languageItem) {
			if (isset($languageItem['scripts']) && $this->script && strpos((string) $languageItem['scripts'], $this->script) !== FALSE) $scriptIsValid = TRUE;
			if (isset($languageItem['territories']) && $this->region && strpos((string) $languageItem['territories'], $this->region) !== FALSE) $regionIsValid = TRUE;
		}
		return ($scriptIsValid && $regionIsValid);
	}

	/**
	 * Returns the locale identifier of this locale
	 *
	 * @param boolean $asArray If set TRUE the language identifier will be returned as an array
	 * @return mixed The language identifier
	 * @author Arno Dudek <webmaster@adgrafik.at>
	 */
	public function getLocaleIdentifier($asArray = FALSE) {
		if ($asArray === TRUE) {
			return array(
				'language' => $this->language,
				'script' => $this->script,
				'region' => $this->region,
				'variants' => $this->variants,
				'extensions' => $this->extensions,
			);
		} else {
			return $this->language . ($this->script ?  '_' . $this->script : '') . ($this->region ?  '_' . $this->region : '') . (count($this->variants) ?  '_' . implode('_', $this->variants) : '') . (count($this->extensions) ?  '_' . implode('_', $this->extensions) : '');
		}
	}

	/**
	 * Returns the language identifier
	 *
	 * @return string The language identifier
	 * @author Arno Dudek <webmaster@adgrafik.at>
	 */
	public function getLanguageIdentifier() {
		return $this->region ? $this->language . '_' . $this->region : $this->language;
	}

	/**
	 * Returns the next match language identifier
	 * Cycle: de > de_DE; de_AT > de_DE; de_DE > de. If no matching locale is found in the CLDR,
	 * it returns only the language.
	 *
	 * @return string The next match language identifier
	 * @author Arno Dudek <webmaster@adgrafik.at>
	 */
	public function getNextMatchLanguageIdentifier() {
		$cldrReader = $this->objectManager->getObject('F3\Core\Internationalization\CLDR\CLDRReader')->loadLikelySubtags();
		if (($info = $cldrReader->findLikelySubtagInfo($this->language)) !== NULL) {
			if ($this->region !== $info['region']){
				return $this->language . '_' . $info['region'];
			} else {
				return $this->language;
			}
		}
		return $this->language;
	}

	/**
	 * Returns the language defined in this locale
	 *
	 * @return string The language identifier
	 * @author Robert Lemke <robert@typo3.org>
	 */
	public function getLanguage() {
		return $this->language;
	}

	/**
	 * Returns the script defined in this locale
	 *
	 * @return string The script identifier
	 * @author Robert Lemke <robert@typo3.org>
	 */
	public function getScript() {
		return $this->script;
	}

	/**
	 * Returns the region defined in this locale
	 *
	 * @return string The region identifier
	 * @author Robert Lemke <robert@typo3.org>
	 */
	public function getRegion() {
		return $this->region;
	}

	/**
	 * Returns all variants defined in this locale
	 *
	 * @return array All variants
	 * @author Arno Dudek <webmaster@adgrafik.at>
	 */
	public function getVariants() {
		return $this->variants;
	}

	/**
	 * Returns all extensions defined in this locale
	 *
	 * @return array All extensions
	 * @author Arno Dudek <webmaster@adgrafik.at>
	 */
	public function getExtensions() {
		return $this->extensions;
	}

}
?>