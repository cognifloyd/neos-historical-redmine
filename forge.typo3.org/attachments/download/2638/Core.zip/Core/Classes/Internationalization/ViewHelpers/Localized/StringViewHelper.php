<?php
declare(ENCODING = 'utf-8');
namespace F3\Core\Internationalization\ViewHelpers\Localized;

/*                                                                        *
 * This script belongs to the FLOW3 framework.                            *
 *                                                                        *
 * It is free software; you can redistribute it and/or modify it under    *
 * the terms of the GNU Lesser General Public License as published by the *
 * Free Software Foundation, either version 3 of the License, or (at your *
 * option) any later version.                                             *
 *                                                                        *
 * This script is distributed in the hope that it will be useful, but     *
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHAN-    *
 * TABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser       *
 * General Public License for more details.                               *
 *                                                                        *
 * You should have received a copy of the GNU Lesser General Public       *
 * License along with the script.                                         *
 * If not, see http://www.gnu.org/licenses/lgpl.html                      *
 *                                                                        *
 * The TYPO3 project - inspiring people to share!                         *
 *                                                                        */

/**
 * Localized string ViewHelper class
 *
 * = Examples =
 *
 * <code title="Localized string (e.g. in the YAML-file Standard/en_US/LocalizedStrings.yaml)">
 * exampleString1: 'Firstname:'
 * exampleString2:
 *   1: 'My %sst %s String for {split: Me, You}'
 *   2: 'My %snd %s String for {split: Me, You}'
 *   4: 'My %sth %s String for {split: Me, You}'
 * </code>
 * <code title="Usage in template file">
 * <lang:localized.string key="exampleString1"/> A name
 * </code>
 * <output>
 * Firstname: A name
 * </output>
 *
 * </code>
 * <code title="Example 2: Replace strings, Plurals and split options">
 * 1: <lang:localized.string key="exampleString2" packageName="AnotherPackage" controllerName="AnotherController" replaceStrings="{0: 1, 1: 'replaced'}" pluralValue="1" splitKey="0"/>
 * 2: <lang:localized.string key="exampleString2" packageName="AnotherPackage" controllerName="AnotherController" replaceStrings="{0: 2, 1: 'replaced'}" pluralValue="2" splitKey="1"/>
 * 3: <lang:localized.string key="exampleString2" packageName="AnotherPackage" controllerName="AnotherController" replaceStrings="{0: 3, 1: 'replaced'}" pluralValue="3" splitKey="0"/>
 * 4: <lang:localized.string key="exampleString2" packageName="AnotherPackage" controllerName="AnotherController" replaceStrings="{0: 4, 1: 'replaced'}" pluralValue="4" splitKey="1"/>
 * 5: <lang:localized.string key="exampleString2" packageName="AnotherPackage" controllerName="AnotherController" replaceStrings="{0: 5, 1: 'replaced'}" pluralValue="5" splitKey="0"/>
 * </code>
 * <output>
 * 1: My 1st replaced String for Me
 * 2: My 2nd replaced String for You
 * 3: My 3nd replaced String for Me   // Here you can see "3nd" cause this is missing in the language file.
 * 4: My 4th replaced String for You
 * 5: My 5th replaced String for Me  // Plural values greater than or equal to the current value takes the last matching.
 * </output>
 *
 * @version $Id: $
 * @license http://www.gnu.org/licenses/lgpl.html GNU Lesser General Public License, version 3 or later
 * @author Arno Dudek <webmaster@adgrafik.at>
 * @scope prototype
 */
class StringViewHelper extends \F3\Fluid\Core\ViewHelper\AbstractViewHelper {

	/**
	 * @var \F3\FLOW3\Object\ObjectManagerInterface
	 */
	protected $objectManager;

	/**
	 * @var \F3\Core\Internationalization\StringLocalization
	 */
	protected $stringLocalization;

	/**
	 * Injects the string localization class
	 *
	 * @param \F3\Core\Internationalization\StringLocalization $stringLocalization
	 * @return void
	 * @author Arno Dudek <webmaster@adgrafik.at>
	 */
	public function injectStringLocalization(\F3\Core\Internationalization\StringLocalization $stringLocalization) {
		$this->stringLocalization = $stringLocalization;
	}

	/**
	 * @param string $key The key from the $languageRepository for which to return the value.
	 * @param string $packageName The name of the package
	 * @param string $subPackageName The name of the sub package
	 * @param string $controllerName The name of the controller
	 * @param array $replaceStrings the arguments of the extension, being passed over to vsprintf
	 * @param integer $pluralValue
	 * @param integer $splitKey
	 * @param boolean $htmlEscape TRUE if the result should be htmlescaped.
	 * @return string Rendered string
	 * @author Arno Dudek <webmaster@adgrafik.at>
	 */
	public function render($key, $packageName = NULL, $subPackageName = NULL, $controllerName = NULL, array $replaceStrings = NULL, $pluralValue = NULL, $splitKey = NULL, $htmlEscape = NULL) {
		$request = $this->controllerContext->getRequest();
		$controllerName = $controllerName ? $controllerName : $request->getControllerName();
		$packageName = $packageName ? $packageName : $request->getControllerPackageKey();

		$value = $this->stringLocalization->getLocalizedString($key, $packageName, $subPackageName, $controllerName, $replaceStrings, $pluralValue, $splitKey, NULL, $htmlEscape);

		return ($value === NULL) ? $this->renderChildren() : $value;
	}
}


?>