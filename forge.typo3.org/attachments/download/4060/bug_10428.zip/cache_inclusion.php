<?php
namespace OtherNamespace;

class FindBug {
	public function run() {
		// Include a file with namespace and __halt_compiler
		require_once(__DIR__ . '/cached_file.php');

		// Requiring another file in between solves the problem!!!
		// require_once(__DIR__ . '/other_class.php');

		// Include a file with class on global namespace
		require_once(__DIR__ . '/some_class.php');
		// The class should exists
		if (!class_exists('\SomeClass')) {
			echo "FAIL: '\SomeClass' not found\n";
		} else {
			echo "OK: '\SomeClass' exists\n";
		}
	}
}

$f = new FindBug();
$f->run();

?>