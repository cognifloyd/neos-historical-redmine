<?php

class SomeClass {
	
}

?>