<?php
namespace CachedTestNamespace;

class CachedClass {
	
}

__halt_compiler();	Test	Arguments