<?php
namespace RandomOrGlobalNamespace;

class OtherClass {
	
}

?>