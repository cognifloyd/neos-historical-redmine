<?php
namespace DEMO\Ztest\Controller;

/***************************************************************
 *  Copyright notice
 *
 *  (c) 2014 
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 *
 *
 * @license http://www.gnu.org/licenses/gpl.html GNU General Public License, version 3 or later
 *
 */
class FatherController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController {

	/**
	 * fatherRepository
	 *
	 * @var \DEMO\Ztest\Domain\Repository\FatherRepository
	 * @inject
	 */
	protected $fatherRepository;

	/**
	 * action list
	 *
	 * @return void
	 */
	public function listAction() {
		
		$fathers = $this->fatherRepository->findAll();
		$this->view->assign('fathers', $fathers);
	}

	/**
	 * action show
	 *
	 * @param \DEMO\Ztest\Domain\Model\Father $father
	 * @return void
	 */
	public function showAction(\DEMO\Ztest\Domain\Model\Father $father) {
		
		$this->view->assign('father', $father);
	}

	/**
	 * action new
	 *
	 * @param \DEMO\Ztest\Domain\Model\Father $newFather
	 * @dontvalidate $newFather
	 * @return void
	 */
	public function newAction(\DEMO\Ztest\Domain\Model\Father $newFather = NULL) {
		
		$this->view->assign('newFather', $newFather);
	}

	/**
	 * action create
	 *
	 * @param \DEMO\Ztest\Domain\Model\Father $newFather
	 * @return void
	 */
	public function createAction(\DEMO\Ztest\Domain\Model\Father $newFather) {
		
		$this->fatherRepository->add($newFather);
		$this->flashMessageContainer->add('Your new Father was created.');
		$this->redirect('list');
	}

	/**
	 * action edit
	 *
	 * @param \DEMO\Ztest\Domain\Model\Father $father
	 * @return void
	 */
	public function editAction(\DEMO\Ztest\Domain\Model\Father $father) {
		
		$this->view->assign('father', $father);
	}

	/**
	 * action update
	 *
	 * @param \DEMO\Ztest\Domain\Model\Father $father
	 * @return void
	 */
	public function updateAction(\DEMO\Ztest\Domain\Model\Father $father) {
		
		$this->fatherRepository->update($father);
		$this->flashMessageContainer->add('Your Father was updated.');
		$this->redirect('list');
	}

	/**
	 * action delete
	 *
	 * @param \DEMO\Ztest\Domain\Model\Father $father
	 * @return void
	 */
	public function deleteAction(\DEMO\Ztest\Domain\Model\Father $father) {
		
		$this->fatherRepository->remove($father);
		$this->flashMessageContainer->add('Your Father was removed.');
		$this->redirect('list');
	}

}
?>