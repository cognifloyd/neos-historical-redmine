<?php
namespace DEMO\Ztest\Tests\Unit\Controller;
/***************************************************************
 *  Copyright notice
 *
 *  (c) 2014 
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Test case for class DEMO\Ztest\Controller\FatherController.
 *
 */
class FatherControllerTest extends \TYPO3\CMS\Extbase\Tests\Unit\BaseTestCase {

	/**
	 * @var DEMO\Ztest\Controller\FatherController
	 */
	protected $subject;

	public function setUp() {
		$this->subject = $this->getMock('DEMO\\Ztest\\Controller\\FatherController', array('redirect', 'forward'), array(), '', FALSE);
	}

	public function tearDown() {
		unset($this->subject);
	}

	/**
	 * @test
	 */
	public function listActionFetchesAllFathersFromRepositoryAndAssignsThemToView() {

		$allFathers = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array(), array(), '', FALSE);

		$fatherRepository = $this->getMock('DEMO\\Ztest\\Domain\\Repository\\FatherRepository', array('findAll'), array(), '', FALSE);
		$fatherRepository->expects($this->once())->method('findAll')->will($this->returnValue($allFathers));
		$this->inject($this->subject, 'fatherRepository', $fatherRepository);

		$view = $this->getMock('TYPO3\\CMS\\Extbase\\Mvc\\View\\ViewInterface');
		$view->expects($this->once())->method('assign')->with('fathers', $allFathers);
		$this->inject($this->subject, 'view', $view);

		$this->subject->listAction();
	}

	/**
	 * @test
	 */
	public function showActionAssignsTheGivenFatherToView() {
		$father = new \DEMO\Ztest\Domain\Model\Father();

		$view = $this->getMock('TYPO3\\CMS\\Extbase\\Mvc\\View\\ViewInterface');
		$this->inject($this->subject, 'view', $view);
		$view->expects($this->once())->method('assign')->with('father', $father);

		$this->subject->showAction($father);
	}

	/**
	 * @test
	 */
	public function newActionAssignsTheGivenFatherToView() {
		$father = new \DEMO\Ztest\Domain\Model\Father();

		$view = $this->getMock('TYPO3\\CMS\\Extbase\\Mvc\\View\\ViewInterface');
		$view->expects($this->once())->method('assign')->with('newFather', $father);
		$this->inject($this->subject, 'view', $view);

		$this->subject->newAction($father);
	}

	/**
	 * @test
	 */
	public function createActionAddsTheGivenFatherToFatherRepository() {
		$father = new \DEMO\Ztest\Domain\Model\Father();

		$fatherRepository = $this->getMock('DEMO\\Ztest\\Domain\\Repository\\FatherRepository', array('add'), array(), '', FALSE);
		$fatherRepository->expects($this->once())->method('add')->with($father);
		$this->inject($this->subject, 'fatherRepository', $fatherRepository);

		$flashMessageContainer = $this->getMock('TYPO3\\CMS\\Extbase\\Mvc\\Controller\\FlashMessageContainer', array('add'), array(), '', FALSE);
		$this->inject($this->subject, 'flashMessageContainer', $flashMessageContainer);

		$this->subject->createAction($father);
	}

	/**
	 * @test
	 */
	public function createActionAddsMessageToFlashMessageContainer() {
		$father = new \DEMO\Ztest\Domain\Model\Father();

		$fatherRepository = $this->getMock('DEMO\\Ztest\\Domain\\Repository\\FatherRepository', array('add'), array(), '', FALSE);
		$this->inject($this->subject, 'fatherRepository', $fatherRepository);

		$flashMessageContainer = $this->getMock('TYPO3\\CMS\\Extbase\\Mvc\\Controller\\FlashMessageContainer', array('add'), array(), '', FALSE);
		$flashMessageContainer->expects($this->once())->method('add');
		$this->inject($this->subject, 'flashMessageContainer', $flashMessageContainer);

		$this->subject->createAction($father);
	}

	/**
	 * @test
	 */
	public function createActionRedirectsToListAction() {
		$father = new \DEMO\Ztest\Domain\Model\Father();

		$fatherRepository = $this->getMock('DEMO\\Ztest\\Domain\\Repository\\FatherRepository', array('add'), array(), '', FALSE);
		$this->inject($this->subject, 'fatherRepository', $fatherRepository);

		$flashMessageContainer = $this->getMock('TYPO3\\CMS\\Extbase\\Mvc\\Controller\\FlashMessageContainer', array('add'), array(), '', FALSE);
		$this->inject($this->subject, 'flashMessageContainer', $flashMessageContainer);

		$this->subject->expects($this->once())->method('redirect')->with('list');
		$this->subject->createAction($father);
	}

	/**
	 * @test
	 */
	public function editActionAssignsTheGivenFatherToView() {
		$father = new \DEMO\Ztest\Domain\Model\Father();

		$view = $this->getMock('TYPO3\\CMS\\Extbase\\Mvc\\View\\ViewInterface');
		$this->inject($this->subject, 'view', $view);
		$view->expects($this->once())->method('assign')->with('father', $father);

		$this->subject->editAction($father);
	}

	/**
	 * @test
	 */
	public function updateActionUpdatesTheGivenFatherInFatherRepository() {
		$father = new \DEMO\Ztest\Domain\Model\Father();

		$fatherRepository = $this->getMock('DEMO\\Ztest\\Domain\\Repository\\FatherRepository', array('update'), array(), '', FALSE);
		$fatherRepository->expects($this->once())->method('update')->with($father);
		$this->inject($this->subject, 'fatherRepository', $fatherRepository);

		$flashMessageContainer = $this->getMock('TYPO3\\CMS\\Extbase\\Mvc\\Controller\\FlashMessageContainer', array('add'), array(), '', FALSE);
		$this->inject($this->subject, 'flashMessageContainer', $flashMessageContainer);

		$this->subject->updateAction($father);
	}

	/**
	 * @test
	 */
	public function updateActionAddsMessageToFlashMessageContainer() {
		$father = new \DEMO\Ztest\Domain\Model\Father();

		$fatherRepository = $this->getMock('DEMO\\Ztest\\Domain\\Repository\\FatherRepository', array('update'), array(), '', FALSE);
		$this->inject($this->subject, 'fatherRepository', $fatherRepository);

		$flashMessageContainer = $this->getMock('TYPO3\\CMS\\Extbase\\Mvc\\Controller\\FlashMessageContainer', array('add'), array(), '', FALSE);
		$flashMessageContainer->expects($this->once())->method('add');
		$this->inject($this->subject, 'flashMessageContainer', $flashMessageContainer);

		$this->subject->updateAction($father);
	}

	/**
	 * @test
	 */
	public function updateActionRedirectsToListAction() {
		$father = new \DEMO\Ztest\Domain\Model\Father();

		$fatherRepository = $this->getMock('DEMO\\Ztest\\Domain\\Repository\\FatherRepository', array('update'), array(), '', FALSE);
		$this->inject($this->subject, 'fatherRepository', $fatherRepository);

		$flashMessageContainer = $this->getMock('TYPO3\\CMS\\Extbase\\Mvc\\Controller\\FlashMessageContainer', array('add'), array(), '', FALSE);
		$this->inject($this->subject, 'flashMessageContainer', $flashMessageContainer);

		$this->subject->expects($this->once())->method('redirect')->with('list');
		$this->subject->updateAction($father);
	}

	/**
	 * @test
	 */
	public function deleteActionRemovesTheGivenFatherFromFatherRepository() {
		$father = new \DEMO\Ztest\Domain\Model\Father();

		$fatherRepository = $this->getMock('DEMO\\Ztest\\Domain\\Repository\\FatherRepository', array('remove'), array(), '', FALSE);
		$fatherRepository->expects($this->once())->method('remove')->with($father);
		$this->inject($this->subject, 'fatherRepository', $fatherRepository);

		$flashMessageContainer = $this->getMock('TYPO3\\CMS\\Extbase\\Mvc\\Controller\\FlashMessageContainer', array('add'), array(), '', FALSE);
		$this->inject($this->subject, 'flashMessageContainer', $flashMessageContainer);

		$this->subject->deleteAction($father);
	}

	/**
	 * @test
	 */
	public function deleteActionAddsMessageToFlashMessageContainer() {
		$father = new \DEMO\Ztest\Domain\Model\Father();

		$fatherRepository = $this->getMock('DEMO\\Ztest\\Domain\\Repository\\FatherRepository', array('remove'), array(), '', FALSE);
		$this->inject($this->subject, 'fatherRepository', $fatherRepository);

		$flashMessageContainer = $this->getMock('TYPO3\\CMS\\Extbase\\Mvc\\Controller\\FlashMessageContainer', array('add'), array(), '', FALSE);
		$flashMessageContainer->expects($this->once())->method('add');
		$this->inject($this->subject, 'flashMessageContainer', $flashMessageContainer);

		$this->subject->deleteAction($father);
	}

	/**
	 * @test
	 */
	public function deleteActionRedirectsToListAction() {
		$father = new \DEMO\Ztest\Domain\Model\Father();

		$fatherRepository = $this->getMock('DEMO\\Ztest\\Domain\\Repository\\FatherRepository', array('remove'), array(), '', FALSE);
		$this->inject($this->subject, 'fatherRepository', $fatherRepository);

		$flashMessageContainer = $this->getMock('TYPO3\\CMS\\Extbase\\Mvc\\Controller\\FlashMessageContainer', array('add'), array(), '', FALSE);
		$this->inject($this->subject, 'flashMessageContainer', $flashMessageContainer);

		$this->subject->expects($this->once())->method('redirect')->with('list');
		$this->subject->deleteAction($father);
	}
}
