﻿.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../Includes.txt


.. _changelog:

ChangeLog
=========

.. note::
	It is recommended to provide the User with a URL pointing to a roadmap_. Forge gives the possibility to
	create a Roadmap very easily. Optionally, the link could point to the `repository log`_.

.. _source code: http://git.typo3.org/
.. _stable versions: http://typo3.org/extensions/repository/
.. _roadmap: http://forge.typo3.org/projects/typo3v4-official_extension_template/roadmap
.. _repository log: http://git.typo3.org/TYPO3v4/Core.git?a=shortlog