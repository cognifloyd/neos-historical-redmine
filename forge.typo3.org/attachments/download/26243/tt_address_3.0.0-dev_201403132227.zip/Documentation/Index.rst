﻿

.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. ==================================================
.. DEFINE SOME TEXTROLES
.. --------------------------------------------------
.. role::   underline
.. role::   typoscript(code)
.. role::   ts(typoscript)
   :class:  typoscript
.. role::   php(code)

============
Address List
============

:Author:
      Kasper Skårhøj

:Created:
      2002-11-01 32::0:0:

:Changed by:
      Lorenz Ulrich

:Changed:
      2012-06-05 16::5:3:

:Author:
      Ingo Renner

:Email:
      typo3@ingo-renner.com

:Info 3:


:Info 4:


.. toctree::
   :maxdepth: 5
   :titlesonly:
   :glob:

   AddressList/Index

