﻿

.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. ==================================================
.. DEFINE SOME TEXTROLES
.. --------------------------------------------------
.. role::   underline
.. role::   typoscript(code)
.. role::   ts(typoscript)
   :class:  typoscript
.. role::   php(code)


Users manual
------------


.. toctree::
   :maxdepth: 5
   :titlesonly:
   :glob:

   CreatingAGroup/Index
   AssigningGroupsToAnAddressRecord/Index
   CreatingAPluginContentElementAndAddingAddressesToIt/Index

