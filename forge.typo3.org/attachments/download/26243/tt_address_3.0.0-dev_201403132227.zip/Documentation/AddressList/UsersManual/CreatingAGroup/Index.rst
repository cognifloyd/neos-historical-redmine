﻿.. include:: Images.txt

.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. ==================================================
.. DEFINE SOME TEXTROLES
.. --------------------------------------------------
.. role::   underline
.. role::   typoscript(code)
.. role::   ts(typoscript)
   :class:  typoscript
.. role::   php(code)


Creating a Group
^^^^^^^^^^^^^^^^

At first you need to create some groups for your address records. To
do this navigate to a sysfolder and switch to the list view. Click
“Create new record” at the bottom, now click Address Group.

|img-2| In that form the title is the only required field, if you have
created some groups already you will see them in the tree view and can
select one as the parent group for the group you are about to create.
At the bottom you can add a small note or description to the group.

