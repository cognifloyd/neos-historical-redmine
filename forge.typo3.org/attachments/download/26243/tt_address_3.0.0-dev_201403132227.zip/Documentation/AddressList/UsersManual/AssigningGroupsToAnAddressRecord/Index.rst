﻿.. include:: Images.txt

.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. ==================================================
.. DEFINE SOME TEXTROLES
.. --------------------------------------------------
.. role::   underline
.. role::   typoscript(code)
.. role::   ts(typoscript)
   :class:  typoscript
.. role::   php(code)


Assigning groups to an address record
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Adding groups to an address is as easy as adding a parent group to
another group. Open the address record you want to assign a group to
or create a new address record, go to the bottom of the form and add
one or more groups from the right box by clicking on the group.

|img-3| When adding groups to an address there's one point to be aware
of: The top most group you assign to an address can be put out in the
front end later, so you might want to choose that carefully or switch
positions of the selected groups.

