﻿

.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. ==================================================
.. DEFINE SOME TEXTROLES
.. --------------------------------------------------
.. role::   underline
.. role::   typoscript(code)
.. role::   ts(typoscript)
   :class:  typoscript
.. role::   php(code)


Updating from tt\_address versions before 2.0.0
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

If you're updating from a tt\_address version < 2.0.0 and the
addressgroups extension there's an update script for you!

Go to the extension manager, select tt\_address and in the upper right
corner you'll find a drop down menu with an element called “UPDATE!”.
The update script will split names from the old combined name field to
first and last name. Although there's also a new middle name field it
is not used by the update script. Names are split by comma (expecting
the part in front of the comma to be the last name and the part after
the comma to be the first name) or by space (expecting the first word
to be the first name and the part after the first space to be the last
name even if there're more space). Records which couldn't be updated
automatically will be highlighted in the update log afterwards, edit
them by hand.

If you have installed EXT:addressgroups this will also be taken into
account. The update script copies the groups to the new tt\_address
native table and rebuilds the relations. Addressgroups plugin content
elements will also be updated to tt\_address plugin content elements.

After that you need to update your HTML templates by hand, the
###NAME### marker from addressgroups is not available in tt\_address,
instead you need to use the respective markers ###FIRSTNAME##,
###MIDDLENAME###, and ###LASTNAME###. Also don't forget to update the
TS from plugin.tx\_addressgroups\_pi1 to plugin.tx\_ttaddress\_pi1!

If you're using other extensions which extend tt\_address there's one
more thing which needs your attention:After you updated your records
to use the split name fields you can disable the old field from the
extension manager. Althoug you disabled the old combined name field
from displaying in the back end tt\_address takes care of writing
changes from the split name fields back to the combined name field.
From the extension manager you can configure the format to use or
which fits your previous record naming. Thus other extensions can
still use the old – now internal – combined name field.

