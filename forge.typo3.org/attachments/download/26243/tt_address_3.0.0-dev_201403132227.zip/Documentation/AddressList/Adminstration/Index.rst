﻿

.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. ==================================================
.. DEFINE SOME TEXTROLES
.. --------------------------------------------------
.. role::   underline
.. role::   typoscript(code)
.. role::   ts(typoscript)
   :class:  typoscript
.. role::   php(code)


Adminstration
-------------

There's not much to say about administration here, just install the
extension. After installation you need to configure the extension. For
that, please consult the next section.


.. toctree::
   :maxdepth: 5
   :titlesonly:
   :glob:

   UpdatingFromTtAddressVersionsBefore200/Index

