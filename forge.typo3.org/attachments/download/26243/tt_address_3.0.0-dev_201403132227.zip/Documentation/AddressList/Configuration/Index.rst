﻿

.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. ==================================================
.. DEFINE SOME TEXTROLES
.. --------------------------------------------------
.. role::   underline
.. role::   typoscript(code)
.. role::   ts(typoscript)
   :class:  typoscript
.. role::   php(code)


Configuration
-------------

When starting to configure the extension you should create a separate
TS extension template for it where you do all the configuration for
this extension. That extension template can then get included in the
root template. In the extension template add the static TS
configuration, otherwise it wont work!


.. toctree::
   :maxdepth: 5
   :titlesonly:
   :glob:

   Img-6/Index
   Reference/Index
   BackendConfiguration/Index

