﻿

.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. ==================================================
.. DEFINE SOME TEXTROLES
.. --------------------------------------------------
.. role::   underline
.. role::   typoscript(code)
.. role::   ts(typoscript)
   :class:  typoscript
.. role::   php(code)


Reference
^^^^^^^^^

.. ### BEGIN~OF~TABLE ###

.. container:: table-row

   Property
         Property:
   
   Data type
         Data type:
   
   Description
         Description:
   
   Default
         Default:


.. container:: table-row

   Property
         templatePath
   
   Data type
         string
   
   Description
         Defines the path where the templates are located. Put templates in
         that folder and they will be listed automatically in the plugin. You
         can also add a small graphic showing how the address will be
         displayed. That graphic need to have the same name as the template but
         must be a gif. This basically works like the template selector from
         MTB2.
   
   Default
         fileadmin/templates/


.. container:: table-row

   Property
         defaultTemplateFileName
   
   Data type
         string
   
   Description
         Defines the default template file.
   
   Default
         addressgroups\_default.htm


.. container:: table-row

   Property
         pidList
   
   Data type
         int
   
   Description
         A comma separated list of integers representing page ids where to get
         the address records from
   
   Default
         0


.. container:: table-row

   Property
         recursive
   
   Data type
         int
   
   Description
         Defines how many levels to search for tt\_address records from the
         given pages in pidList.
   
   Default
         0


.. container:: table-row

   Property
         wrap
   
   Data type
         string
   
   Description
         wraps the whole output
   
   Default


.. container:: table-row

   Property
         singleSelection
   
   Data type
         stdWrap
   
   Description
         Comma separated list of tt\_address record uids, will be overriden
         with flexform data
   
   Default


.. container:: table-row

   Property
         groupSelection
   
   Data type
         stdWrap
   
   Description
         Comma separated list of tt\_address group record uids, will be
         overriden with flexform data
   
   Default


.. container:: table-row

   Property
         combination
   
   Data type
         int
   
   Description
         0 = AND, 1 = OR
   
   Default
         0


.. container:: table-row

   Property
         sortByColumn
   
   Data type
         string
   
   Description
         Defines by which tt\_address column you want to sort, if an invalid
         column is given it's set to 'name'
         
         Valid columns for sorting:
         
         uid, pid, tstamp, name, title, email, phone, mobile, www, address,
         company, city, zip, country, image, fax, description
         
         If set to “singleSelection” and only single records are selected by
         TypoScript or Flexform, the sorting order of TypoScript selection of
         Flexform selection is respected.
   
   Default
         name


.. container:: table-row

   Property
         sortOrder
   
   Data type
         string
   
   Description
         Defines the sorting order, DESC for descending and ASC for ascending.
         Any other (invalid) value is set to ASC.
   
   Default
         ASC


.. container:: table-row

   Property
         templates.[TEMPLATE\_NAME]
   
   Data type
         wrap
   
   Description
         wraps a single address
   
   Default


.. container:: table-row

   Property
         templates.[TEMPLATE\_NAME]
   
   Data type
         allWrap
   
   Description
         wraps the whole output of the specific template
   
   Default


.. container:: table-row

   Property
         templates.[TEMPLATE\_NAME].[FIELD\_NAME]
   
   Data type
         stdWrap
   
   Description
         The configurations for the different templates goes here. Let's have a
         look at an example:
         
         Let's assume you have three different html templates:
         
         \* template\_1.htm
         
         \* other\_template.htm
         
         \* different\_template.htm
         
         TEMPLATENAME is the file name without the extension. Now you can
         configure each of these templates:
         
         **Example:**
         
         ::
         
            plugin.tx_ttaddress_pi1 {
              templates.template_1 {
                email.wrap = E-Mail: |<br />
                email.required = 1
                ...
              }
            
              templates.other_template {
                ...
              }
            
              templates.different_template {
                ...
              }
            }
         
         each standard tt\_address field can be configured with stdWrap
         properties. Like wrap and required which will propably be the most
         important and most used ones.
         
         Here's the list of default fields you can use inside each template
         configuration:
         
         gender, first\_name, middle\_name, last\_name, title, email, phone,
         mobile, www, address, building, room, birthday, organization, city,
         zip, region, country, image, fax, description, mainGroup
         
         You can control max width and hight of an image with image.file.maxW
         and image.file.maxH
         
         A placeholder image can be defined:
         
         ::
         
            plugin.tx_ttaddress_pi1.templates.myTemplate.placeholderImage = path/to/placeholder.png
         
         (stdWrap enabled, inherits the configuration of the image)
         
         An example template can be found in the res folder in the extension.
         This template also contains a list of all available markers.
   
   Default


.. container:: table-row

   Property
         templates.[TEMPLATE\_NAME.][subparts]
   
   Data type
   
   
   Description
         Each template configuration can have subparts.
         
         You can define as many subparts as like, stdWrap properties will apply
         to them. If you have a subpart configuration
         
         ::
         
              templates.other_template {
                ...
                subparts {
                  xyz {
            
                  }
                  abc {
            
                  }
                }
              }
         
         you can use these subparts in your HTML template like
         
         <!-- ###SUBPART\_XYZ### begin -->
         
         ...
         
         <!-- ###SUBPART\_XYZ### end -->
         
         <!-- ###SUBPART\_ABC### begin -->
         
         ...
         
         <!-- ###SUBPART\_ABC### end -->
         
         Subparts have a special condition property: hasOneOf, with this
         property you define that an address record must have at least one of
         the defined name fields before the whole subpart is shown:
         
         subparts.abc.hasOneOf = city, zip, country
   
   Default


.. ###### END~OF~TABLE ######

[tsref:plugin.tx\_ttaddress\_pi1]

