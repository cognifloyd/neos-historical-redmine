<?php
namespace Netlogix\DependencyHierarchy\Domain\Model;
use TYPO3\FLOW3\Annotations as FLOW3;

/*                                                                        *
 * This script belongs to the FLOW3 package "Netlogix.DependencyHierarchy"*
 *                                                                        *
 * It is free software; you can redistribute it and/or modify it under    *
 * the terms of the GNU Lesser General Public License, either version 3   *
 * of the License, or (at your option) any later version.                 *
 *                                                                        *
 * The TYPO3 project - inspiring people to share!                         *
 *                                                                        */

class ObjectA {

	/**
	 * @var \TYPO3\FLOW3\Security\Cryptography\HashService
	 * @FLOW3\Inject
	 */
	protected $hashService;

	/**
	 * __construct
	 *
	 * @return void
	 */
	public function __construct() {

		$hashService = $this->hashService;

		echo "\$this:              " . get_class($this) . "\n";
		echo "\$this->hashService: " . (is_null($this->hashService) ? 'NULL' : get_class($hashService)) . "\n";
		echo  "__CLASS__:          " . __CLASS__ . "\n";
		echo "\n\n";

	}

}

?>