<?php
namespace Netlogix\DependencyHierarchy\Command;

/*                                                                        *
 * This script belongs to the FLOW3 package "Netlogix.DependencyHierarchy"*
 *                                                                        *
 * It is free software; you can redistribute it and/or modify it under    *
 * the terms of the GNU Lesser General Public License, either version 3   *
 * of the License, or (at your option) any later version.                 *
 *                                                                        *
 * The TYPO3 project - inspiring people to share!                         *
 *                                                                        */

use Doctrine\ORM\Mapping as ORM;
use TYPO3\FLOW3\Annotations as FLOW3;

/**
 * The TYPO3 Setup
 *
 * @license http://www.gnu.org/licenses/gpl.html GNU General Public License, version 3 or later
 * @FLOW3\Scope("singleton")
 */
class TestCommandController extends \TYPO3\FLOW3\MVC\Controller\CommandController {

	/**
	 * Add the feature templates for position in centimeters
	 *
	 * @return void
	 */
	public function testCommand() {

		/*
		$a = new \Netlogix\DependencyHierarchy\Domain\Model\ObjectA();
		$b = new \Netlogix\DependencyHierarchy\Domain\Model\ObjectB();
		*/

		/**
		 * A extends B, B extends C
		 *
		 * A gets a hashService by DI
		 * C calls $this->hashService, which should be present by As DI configuration.
		 *
		 * A and C directly echo the $this->hashService.
		 *
		 * In A it's obviously not present because DI goes after __construct,
		 * but in C it used to be present in pre 1.1 releases because DI was done right
		 * after the first __construct.
		 */
		$c = new \Netlogix\DependencyHierarchy\Domain\Model\ObjectC();

	}

}
?>