<?php
namespace SF\Sfcombination\Domain\Model;


/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2014 Stefan Frömken <froemken@gmail.com>
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Feature
 */
class Feature extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity {

	/**
	 * Feature
	 *
	 * @var string
	 * @validate NotEmpty
	 */
	protected $feature = '';

	/**
	 * Cars
	 *
	 * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\SF\Sfcombination\Domain\Model\CarFeatureMm>
	 * @cascade remove
	 */
	protected $cars;

	/**
	 * __construct
	 */
	public function __construct() {
		//Do not remove the next line: It would break the functionality
		$this->initStorageObjects();
	}

	/**
	 * Initializes all ObjectStorage properties
	 * Do not modify this method!
	 * It will be rewritten on each save in the extension builder
	 * You may modify the constructor of this class instead
	 *
	 * @return void
	 */
	protected function initStorageObjects() {
		$this->cars = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
	}

	/**
	 * Returns the feature
	 *
	 * @return string $feature
	 */
	public function getFeature() {
		return $this->feature;
	}

	/**
	 * Sets the feature
	 *
	 * @param string $feature
	 * @return void
	 */
	public function setFeature($feature) {
		$this->feature = $feature;
	}

	/**
	 * Adds a CarFeatureMm
	 *
	 * @param \SF\Sfcombination\Domain\Model\CarFeatureMm $car
	 * @return void
	 */
	public function addCar(\SF\Sfcombination\Domain\Model\CarFeatureMm $car) {
		$this->cars->attach($car);
	}

	/**
	 * Removes a CarFeatureMm
	 *
	 * @param \SF\Sfcombination\Domain\Model\CarFeatureMm $carToRemove The CarFeatureMm to be removed
	 * @return void
	 */
	public function removeCar(\SF\Sfcombination\Domain\Model\CarFeatureMm $carToRemove) {
		$this->cars->detach($carToRemove);
	}

	/**
	 * Returns the cars
	 *
	 * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\SF\Sfcombination\Domain\Model\CarFeatureMm> $cars
	 */
	public function getCars() {
		return $this->cars;
	}

	/**
	 * Sets the cars
	 *
	 * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\SF\Sfcombination\Domain\Model\CarFeatureMm> $cars
	 * @return void
	 */
	public function setCars(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $cars) {
		$this->cars = $cars;
	}

}