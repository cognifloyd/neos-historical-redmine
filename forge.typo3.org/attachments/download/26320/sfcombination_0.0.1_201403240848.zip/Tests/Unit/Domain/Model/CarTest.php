<?php

namespace \Tests\Unit\Domain\Model;

/***************************************************************
 *  Copyright notice
 *
 *  (c) 2014 Stefan Frömken <froemken@gmail.com>
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

/**
 * Test case for class \SF\Sfcombination\Domain\Model\Car.
 *
 * @version $Id$
 * @copyright Copyright belongs to the respective authors
 * @license http://www.gnu.org/licenses/gpl.html GNU General Public License, version 3 or later
 *
 * @author Stefan Frömken <froemken@gmail.com>
 */
class CarTest extends \TYPO3\CMS\Extbase\Tests\Unit\BaseTestCase {
	/**
	 * @var \SF\Sfcombination\Domain\Model\Car
	 */
	protected $subject;

	public function setUp() {
		$this->subject = new \SF\Sfcombination\Domain\Model\Car();
	}

	public function tearDown() {
		unset($this->subject);
	}

	/**
	 * @test
	 */
	public function getBrandReturnsInitialValueForString() {
		$this->assertSame(
			'',
			$this->subject->getBrand()
		);
	}

	/**
	 * @test
	 */
	public function setBrandForStringSetsBrand() {
		$this->subject->setBrand('Conceived at T3CON10');

		$this->assertAttributeEquals(
			'Conceived at T3CON10',
			'brand',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function getFeaturesReturnsInitialValueForCarFeatureMm() {
		$newObjectStorage = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$this->assertEquals(
			$newObjectStorage,
			$this->subject->getFeatures()
		);
	}

	/**
	 * @test
	 */
	public function setFeaturesForObjectStorageContainingCarFeatureMmSetsFeatures() {
		$feature = new \SF\Sfcombination\Domain\Model\CarFeatureMm();
		$objectStorageHoldingExactlyOneFeatures = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
		$objectStorageHoldingExactlyOneFeatures->attach($feature);
		$this->subject->setFeatures($objectStorageHoldingExactlyOneFeatures);

		$this->assertAttributeEquals(
			$objectStorageHoldingExactlyOneFeatures,
			'features',
			$this->subject
		);
	}

	/**
	 * @test
	 */
	public function addFeatureToObjectStorageHoldingFeatures() {
		$feature = new \SF\Sfcombination\Domain\Model\CarFeatureMm();
		$featuresObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('attach'), array(), '', FALSE);
		$featuresObjectStorageMock->expects($this->once())->method('attach')->with($this->equalTo($feature));
		$this->inject($this->subject, 'features', $featuresObjectStorageMock);

		$this->subject->addFeature($feature);
	}

	/**
	 * @test
	 */
	public function removeFeatureFromObjectStorageHoldingFeatures() {
		$feature = new \SF\Sfcombination\Domain\Model\CarFeatureMm();
		$featuresObjectStorageMock = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array('detach'), array(), '', FALSE);
		$featuresObjectStorageMock->expects($this->once())->method('detach')->with($this->equalTo($feature));
		$this->inject($this->subject, 'features', $featuresObjectStorageMock);

		$this->subject->removeFeature($feature);

	}
}
