<?php
if (!defined ('TYPO3_MODE')) {
	die ('Access denied.');
}

$TCA['tx_sfcombination_domain_model_carfeaturemm'] = array(
	'ctrl' => $TCA['tx_sfcombination_domain_model_carfeaturemm']['ctrl'],
	'interface' => array(
		'showRecordFieldList' => 'car, feature',
	),
	'types' => array(
		'1' => array('showitem' => 'car, feature'),
	),
	'palettes' => array(
		'1' => array('showitem' => ''),
	),
	'columns' => array(
	
		'car' => array(
			'label' => 'Car',
			'config' => array(
				'type' => 'select',
				'foreign_table' => 'tx_sfcombination_domain_model_car',
				'size' => 1,
				'minitems' => 1,
				'maxitems' => 1,
			),
		),
		'feature' => array(
			'label' => 'Feature',
			'config' => array(
				'type' => 'select',
				'foreign_table' => 'tx_sfcombination_domain_model_feature',
				'size' => 1,
				'minitems' => 1,
				'maxitems' => 1,
			),
		),
	),
);