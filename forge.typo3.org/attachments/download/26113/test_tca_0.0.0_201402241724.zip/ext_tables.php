<?php

if (!defined('TYPO3_MODE')) {
    die ('Access denied.');
}

$TCA['tx_testtca_tableone'] = array(
    'ctrl' => array(
        'title'                    => 'Table One',
        'label'                    => 'title',
        'tstamp'                   => 'tstamp',
        'crdate'                   => 'crdate',
        'cruser_id'                => 'cruser_id',
        'default_sortby'           => 'ORDER BY title',
        'delete'                   => 'deleted',
        'enablecolumns' => array(
            'disabled'  => 'hidden',
            'starttime' => 'starttime',
            'endtime'   => 'endtime',
        ),
        'dynamicConfigFile'        => t3lib_extMgm::extPath($_EXTKEY) . 'tca.php',
        'iconfile'                 => '',
    ),
);

$TCA['tx_testtca_tabletwo'] = array(
    'ctrl' => array(
        'title'                    => 'Table Two',
        'label'                    => 'title',
        'tstamp'                   => 'tstamp',
        'crdate'                   => 'crdate',
        'cruser_id'                => 'cruser_id',
        'default_sortby'           => 'ORDER BY title',
        'delete'                   => 'deleted',
        'dynamicConfigFile'        => t3lib_extMgm::extPath($_EXTKEY) . 'tca.php',
        'iconfile'                 => '',
    ),
);
?>
