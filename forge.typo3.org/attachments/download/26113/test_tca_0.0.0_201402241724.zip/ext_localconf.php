<?php

if (!defined('TYPO3_MODE')) {
    die ('Access denied.');
}

?>
