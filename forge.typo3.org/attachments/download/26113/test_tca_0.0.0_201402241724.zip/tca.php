<?php

defined('TYPO3_MODE') or die('Access denied.');

$table = 'tx_testtca_tableone';
$lll   = '';

$TCA[$table] = array(
    'ctrl' => $TCA[$table]['ctrl'],
    'interface' => array(
        'showRecordFieldList' => 'hidden,starttime,endtime,title,tabletwo'
    ),
    'feInterface' => $TCA[$table]['feInterface'],
    'columns' => array(
        'hidden' => array(
            'exclude' => 1,
            'label'   => 'LLL:EXT:lang/locallang_general.xml:LGL.hidden',
            'config'  => array(
                'type'    => 'check',
                'default' => '0'
            )
        ),
        'starttime' => array(
            'exclude' => 1,
            'label'   => 'LLL:EXT:lang/locallang_general.xml:LGL.starttime',
            'config'  => array(
                'type'     => 'input',
                'size'     => '8',
                'max'      => '20',
                'eval'     => 'date',
                'default'  => '0',
                'checkbox' => '0'
            )
        ),
        'endtime' => array(
            'exclude' => 1,
            'label'   => 'LLL:EXT:lang/locallang_general.xml:LGL.endtime',
            'config'  => array(
                'type'     => 'input',
                'size'     => '8',
                'max'      => '20',
                'eval'     => 'date',
                'default'  => '0',
                'checkbox' => '0',
            )
        ),
        'title' => array(
            'exclude' => 0,
            'label' => $lll . 'title',
            'config' => array(
                'type' => 'input',
                'size' => '16',
                'max' => '64',
                'eval' => 'required,trim',
            )
        ),
        'tabletwo' => array(
            'label'  => 'tabletwo',
            'config' => array(
                'type'   => 'select',
                'foreign_table' => 'tx_testtca_tabletwo',
                'foreign_table_where' => 'ORDER BY tx_testtca_tabletwo.title',
                'internal_type' => 'db',
                'allowed'  => 'tx_testtca_tabletwo',
                'size'     => 10,
                'minitems' => 0,
                'maxitems' => 100,
                'MM'       => 'tx_testtca_tableone_mm_tabletwo',
                'wizards'  => array(
                    '_PADDING' => 2,
                    '_VERTICAL' => true,
                    'add' => array(
                        'type'   => 'script',
                        'title'  => 'Create new record',
                        'icon'   => 'new_record.gif',
                        'params' => array(
                            'table'    => 'tx_testtca_tabletwo',
                            'pid'      => '###CURRENT_PID###',
                            'setValue' => 'prepend'
                        ),
                        'script' => 'wizard_add.php',
                    ),
                    'list' => array(
                        'type'   => 'script',
                        'title'  => 'List',
                        'icon'   => 'list.gif',
                        'params' => array(
                            'table' => 'tx_testtca_tabletwo',
                            'pid'   => '###CURRENT_PID###',
                        ),
                        'script' => 'wizard_list.php',
                    ),
                    'edit' => array(
                        'type'   => 'popup',
                        'title'  => 'Edit',
                        'script' => 'wizard_edit.php',
                        'popup_onlyOpenIfSelected' => 1,
                        'icon'   => 'edit2.gif',
                        'JSopenParams'
                            => 'height=700,width=700,status=0,menubar=0,'
                            . 'scrollbars=1',
                    ),
                ),
            ),
        ),
    ),
    'types' => array(
        '0' => array('showitem' => ' hidden;;1, title;;;;1-1-1,tabletwo;;;;2-2-2')
    ),
    'palettes' => array(
        '1' => array('showitem' => 'starttime, endtime')
    )
);


$table = 'tx_testtca_tabletwo';
$lll   = '';
$TCA[$table] = array(
    'ctrl' => $TCA[$table]['ctrl'],
    'interface' => array(
        'showRecordFieldList' => 'title,tableone'
    ),
    'feInterface' => $TCA[$table]['feInterface'],
    'columns' => array(
        'title' => array(
            'exclude' => 0,
            'label' => $lll . 'title',
            'config' => array(
                'type' => 'input',
                'size' => '16',
                'max' => '64',
                'eval' => 'required,trim',
            )
        ),
        'tableone' => array(
            'label'  => 'tableone',
            'config' => array(
                'type'   => 'select',
                'foreign_table' => 'tx_testtca_tableone',
                'foreign_table_where' => 'ORDER BY tx_testtca_tableone.title',
                'internal_type' => 'db',
                'allowed'  => 'tx_testtca_tableone',
                'size'     => 10,
                'minitems' => 0,
                'maxitems' => 100,
                'MM'       => 'tx_testtca_tableone_mm_tabletwo',
                'MM_opposite_field' => 'tableone',
                'wizards'  => array(
                    '_PADDING' => 2,
                    '_VERTICAL' => true,
                    'add' => array(
                        'type'   => 'script',
                        'title'  => 'Create new record',
                        'icon'   => 'new_record.gif',
                        'params' => array(
                            'table'    => 'tx_testtca_tableone',
                            'pid'      => '###CURRENT_PID###',
                            'setValue' => 'prepend'
                        ),
                        'script' => 'wizard_add.php',
                    ),
                    'list' => array(
                        'type'   => 'script',
                        'title'  => 'List',
                        'icon'   => 'list.gif',
                        'params' => array(
                            'table' => 'tx_testtca_tableone',
                            'pid'   => '###CURRENT_PID###',
                        ),
                        'script' => 'wizard_list.php',
                    ),
                    'edit' => array(
                        'type'   => 'popup',
                        'title'  => 'Edit',
                        'script' => 'wizard_edit.php',
                        'popup_onlyOpenIfSelected' => 1,
                        'icon'   => 'edit2.gif',
                        'JSopenParams'
                            => 'height=700,width=700,status=0,menubar=0,'
                            . 'scrollbars=1',
                    ),
                ),
            ),
         ),
    ),
    'types' => array(
        '0' => array(
            'showitem' => 'title;;1, tableone;;;;2-2-2'
        )
    ),
    'palettes' => array(
        '1' => array()
    )
);

?>
