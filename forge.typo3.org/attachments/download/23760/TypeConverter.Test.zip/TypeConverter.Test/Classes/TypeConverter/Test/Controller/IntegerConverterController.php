<?php
namespace TypeConverter\Test\Controller;

use TYPO3\Flow\Annotations as Flow;

/**
 * Class IntegerController
 */
class IntegerConverterController extends \TYPO3\Flow\Mvc\Controller\ActionController {

	public function indexAction() {}

	/**
	 * @param \TypeConverter\Test\Domain\Model\DTO\IntegerConverter $integerConverter
	 */
	public function wrongTypeConverterThingyAction(\TypeConverter\Test\Domain\Model\DTO\IntegerConverter $integerConverter) {

	}
}