<?php
namespace TypeConverter\Test\Domain\Model\DTO;

class IntegerConverter {

	/**
	 * @var int
	 */
	protected $someProperty;

	/**
	 * @param int $someProperty
	 */
	public function setSomeProperty($someProperty) {
		$this->someProperty = $someProperty;
	}

	/**
	 * @return int
	 */
	public function getSomeProperty() {
		return $this->someProperty;
	}

}