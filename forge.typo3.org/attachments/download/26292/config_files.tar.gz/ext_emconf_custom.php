<?php

########################################################################
# Extension Manager/Repository config file for ext "user_something_distribution_search".
#
# Auto generated 01-03-2013 13:39
#
# Manual updates:
# Only the data in the array - everything else is removed by next
# writing. "version" and "dependencies" must not be touched!
########################################################################

$EM_CONF[$_EXTKEY] = array(
	'title' => 'Custom distribution search',
	'description' => 'custom distribution search',
	'category' => 'plugin',
	'author' => 'plan2net',
	'author_email' => 'info@plan2.net',
	'shy' => '',
	'dependencies' => 'cms,smarty',
	'conflicts' => '',
	'priority' => '',
	'module' => '',
	'state' => 'beta',
	'internal' => '',
	'uploadfolder' => 0,
	'createDirs' => '',
	'modify_tables' => '',
	'clearCacheOnLoad' => 0,
	'lockType' => '',
	'author_company' => '',
	'version' => '0.9.9',
	'constraints' => array(
		'depends' => array(
			'cms' => '',
			'smarty' => '2.0.0-0.0.0',
		),
		'conflicts' => array(
		),
		'suggests' => array(
		),
	),
	'_md5_values_when_last_written' => '…',
	'suggests' => array(
	),
);

?>
