<?php

/***************************************************************
 * Extension Manager/Repository config file for ext "smarty".
 *
 * Auto generated 26-09-2013 08:43
 *
 * Manual updates:
 * Only the data in the array - everything else is removed by next
 * writing. "version" and "dependencies" must not be touched!
 ***************************************************************/

$EM_CONF[$_EXTKEY] = array (
	'title' => 'smarty',
	'description' => 'Smarty Templating Engine for TYPO3',
	'category' => 'misc',
	'shy' => 0,
	'version' => '2.0.1',
	'dependencies' => '',
	'conflicts' => '',
	'priority' => '',
	'loadOrder' => '',
	'module' => '',
	'state' => 'beta',
	'uploadfolder' => 0,
	'createDirs' => 'typo3temp/smarty_cache,typo3temp/smarty_compile',
	'modify_tables' => '',
	'clearcacheonload' => 0,
	'lockType' => '',
	'author' => 'Simon Tuck',
	'author_email' => 'stu@rtp.ch',
	'author_company' => 'www.rtp.ch',
	'CGLcompliance' => NULL,
	'CGLcompliance_note' => NULL,
	'constraints' => 
	array (
		'depends' => 
		array (
			'php' => '5.3.2-0.0.0',
			'typo3' => '4.5.0-6.1.99',
		),
		'conflicts' => '',
		'suggests' => 
		array (
		),
	),
);

?>
