<?php
if (!defined('TYPO3_MODE')) {
	die ('Access denied.');
}

\TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
	'GeorgRinger.' . $_EXTKEY,
	'Testoverride',
	array(
		'Fo' => 'list, show, new, create, edit, update',
		
	),
	// non-cacheable actions
	array(
		'Fo' => 'create, update',
		
	)
);

?>