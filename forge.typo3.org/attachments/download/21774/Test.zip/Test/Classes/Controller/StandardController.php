<?php
namespace Test\Controller;

/*                                                                        *
 * This script belongs to the FLOW3 package "Test".                       *
 *                                                                        *
 *                                                                        */

use TYPO3\FLOW3\Annotations as FLOW3;

/**
 * Standard controller for the Test package
 *
 * @FLOW3\Scope("singleton")
 */
class StandardController extends \TYPO3\FLOW3\Mvc\Controller\ActionController {

	/**
	 * @var \Test\Domain\Repository\TestRepository
	 * @FLOW3\Inject
	 */
	protected $repository;

	/**
	 * Index action
	 *
	 * @return void
	 */
	public function indexAction() {

		$test = new \Test\Domain\Model\Test();
		$test->setTitle('test');
		$this->repository->add($test);

		\TYPO3\FLOW3\var_dump($test);;


		$this->repository->removeAll();

		$this->view->assign('foos', array(
			'bar', 'baz'
		));
	}

}

?>