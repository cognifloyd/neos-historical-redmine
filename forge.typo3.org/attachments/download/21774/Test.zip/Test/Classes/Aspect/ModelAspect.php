<?php
namespace Test\Aspect;

use TYPO3\FLOW3\Annotations as FLOW3,
	Doctrine\ORM\Mapping as ORM;

/**
  * @FLOW3\Aspect
 */
class ModelAspect {

	/**
	 * @var string
	 * @ORM\Column(length=40)
	 * @FLOW3\Introduce("class(Test\Domain\Model\Test)")
	 */
	protected $fooBarPropertyName;

	/**
	 * After returning advice
	 *
	 * @FLOW3\Before("method(Test\Domain\Repository\TestRepository->removeAll())")
	 */
	public function beforeRemoveAdvice(\TYPO3\FLOW3\AOP\JoinPointInterface $joinPoint) {

	}

}

?>