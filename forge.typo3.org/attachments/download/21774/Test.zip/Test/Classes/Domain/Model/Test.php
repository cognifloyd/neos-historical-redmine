<?php
namespace Test\Domain\Model;

/*                                                                        *
 * This script belongs to the FLOW3 package "Test".                       *
 *                                                                        *
 *                                                                        */

use TYPO3\FLOW3\Annotations as FLOW3;
use Doctrine\ORM\Mapping as ORM;

/**
 * A Test
 *
 * @FLOW3\Entity
 */
class Test {

	/**
	 * @var string
	 */
	protected $title;

	/**
	 * @param string $title
	 */
	public function setTitle($title) {
		$this->title = $title;
	}

	/**
	 * @return string
	 */
	public function getTitle() {
		return $this->title;
	}
}
?>