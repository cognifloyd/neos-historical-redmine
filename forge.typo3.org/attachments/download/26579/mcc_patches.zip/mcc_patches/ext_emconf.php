<?php

$EM_CONF[$_EXTKEY] = array(
	'title' => 'MCC Patches for TYPO3',
	'description' => '',
	'category' => 'plugin',
	'author' => 'Jeff Segars',
	'author_email' => 'jeff.segars@aoe.com',
	'author_company' => 'AOE Media',
	'shy' => '',
	'priority' => '',
	'module' => '',
	'state' => 'stable',
	'internal' => '',
	'uploadfolder' => 0,
	'createDirs' => '',
	'modify_tables' => '',
	'clearCacheOnLoad' => 0,
	'lockType' => '',
	'version' => '1.0.0',
	'constraints' => array(
		'depends' => array(
			'extbase' => '6.0',
			'fluid' => '6.0',
			'typo3' => '6.0-6.2.99'
		),
		'conflicts' => array(
		),
		'suggests' => array(
		),
	),
	'_md5_values_when_last_written' => 'a:21:{s:10:"README.txt";s:4:"d41d";s:16:"ext_autoload.php";s:4:"109b";s:12:"ext_icon.gif";s:4:"e922";s:17:"ext_localconf.php";s:4:"3e6c";s:14:"ext_tables.php";s:4:"1c7d";s:37:"Classes/Controller/FormController.php";s:4:"beb0";s:33:"Classes/Service/EloquaService.php";s:4:"856c";s:32:"Classes/Service/EmailService.php";s:4:"ce58";s:30:"Classes/Service/LogService.php";s:4:"9a67";s:42:"Configuration/FlexForms/flexform_forms.xml";s:4:"f1f5";s:38:"Configuration/TypoScript/constants.txt";s:4:"d860";s:34:"Configuration/TypoScript/setup.txt";s:4:"cf68";s:38:"Resources/Private/Layouts/Default.html";s:4:"fc3c";s:47:"Resources/Private/Templates/Email/Download.html";s:4:"f021";s:51:"Resources/Private/Templates/Email/Notification.html";s:4:"a1e7";s:42:"Resources/Private/Templates/Form/Form.html";s:4:"4efd";s:44:"Resources/Private/Templates/Form/Submit.html";s:4:"585a";s:42:"Resources/Public/JavaScript/application.js";s:4:"b3ba";s:57:"Resources/Public/JavaScript/jquery.maskedinput-1.3.min.js";s:4:"8ac5";s:46:"Resources/Public/JavaScript/jquery.validate.js";s:4:"f245";s:58:"Resources/Public/JavaScript/jquery.validation.functions.js";s:4:"9eb4";}',
);

?>