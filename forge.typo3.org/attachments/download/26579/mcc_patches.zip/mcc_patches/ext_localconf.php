<?php
if (!defined('TYPO3_MODE')) {
	die ('Access denied.');
}

$GLOBALS['TYPO3_CONF_VARS']['SYS']['Objects']['TYPO3\\CMS\\Core\\Resource\\FileRepository'] = array(
	'className' => 'MCC\\MccPatches\\Xclass\\FileRepository'
);

$GLOBALS['TYPO3_CONF_VARS']['SYS']['Objects']['TYPO3\\CMS\\Core\\DataHandling\\DataHandler'] = array(
	'className' => 'MCC\\MccPatches\\Xclass\\DataHandler'
);

$GLOBALS['TYPO3_CONF_VARS']['SYS']['Objects']['t3lib_TCEmain'] = array(
	'className' => 'MCC\\MccPatches\\Xclass\\DataHandler'
);


?>