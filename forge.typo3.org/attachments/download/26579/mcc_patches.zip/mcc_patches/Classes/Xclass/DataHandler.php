<?php
namespace MCC\MccPatches\Xclass;

class DataHandler extends \TYPO3\CMS\Core\DataHandling\DataHandler {

	/**
	 * Callback function for traversing the FlexForm structure in relation to creating copied files of file relations inside of flex form structures.
	 *
	 * @param array $pParams Array of parameters in num-indexes: table, uid, field
	 * @param array $dsConf TCA field configuration (from Data Structure XML)
	 * @param string $dataValue The value of the flexForm field
	 * @param string $dataValue_ext1 Not used.
	 * @param string $dataValue_ext2 Not used.
	 * @return array Result array with key "value" containing the value of the processing.
	 * @see copyRecord(), checkValue_flex_procInData_travDS()
	 * @todo Define visibility
	 */
	public function copyRecord_flexFormCallBack($pParams, $dsConf, $dataValue, $dataValue_ext1, $dataValue_ext2) {
		// Extract parameters:
		list($table, $uid, $field, $realDestPid) = $pParams;
		// Process references and files, currently that means only the files, prepending absolute paths:
		$dataValue = $this->copyRecord_procFilesRefs($dsConf, $uid, $dataValue);
		// If references are set for this field, set flag so they can be corrected later (in ->remapListedDBRecords())
		// @note The check for inline field types is a patch to fix copying of flexforms with inline elements.
		if (($this->isReferenceField($dsConf) || $this->getInlineFieldType($dsConf)) && strlen($dataValue)) {
			$dataValue = $this->copyRecord_procBasedOnFieldType($table, $uid, $field, $dataValue, array(), $dsConf, $realDestPid);
			$this->registerDBList[$table][$uid][$field] = 'FlexForm_reference';
		}
		// Return
		return array('value' => $dataValue);
	}



}

?>