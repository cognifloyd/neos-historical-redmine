<?php
namespace MCC\MccPatches\Xclass;

class FileRepository extends \TYPO3\CMS\Core\Resource\FileRepository {

	/**
	 * Find FileReference objects by relation to other records
	 *
	 * @param int $tableName Table name of the related record
	 * @param int $fieldName Field name of the related record
	 * @param int $uid The UID of the related record (needs to be the localized uid, as translated IRRE elements relate to them)
	 * @return array An array of objects, empty if no objects found
	 * @throws \InvalidArgumentException
	 * @api
	 */
	 public function findByRelation($tableName, $fieldName, $uid) {
		$itemList = array();
		if (!\TYPO3\CMS\Core\Utility\MathUtility::canBeInterpretedAsInteger($uid)) {
			throw new \InvalidArgumentException('Uid of related record has to be an integer.', 1316789798);
		}

		// @note This block is a patch to ensure that workspaces are taken into account before querying with the uid
		$considerWorkspaces = !empty($GLOBALS['BE_USER']->workspace) && \TYPO3\CMS\Backend\Utility\BackendUtility::isTableWorkspaceEnabled($tableName) ? 1 : 0;
		if($considerWorkspaces) {
			$row = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows(
				'*',
				$tableName,
				'uid=' . intval($uid)
			);
			$row = $row[0];
			\TYPO3\CMS\Backend\Utility\BackendUtility::workspaceOL($tableName, $row);
			if(isset($row['_ORIG_uid'])) {
				$uid = $row['_ORIG_uid'];
			}
		}
		// end block

		$references = $GLOBALS['TYPO3_DB']->exec_SELECTgetRows(
			'*',
			'sys_file_reference',
			'tablenames=' . $GLOBALS['TYPO3_DB']->fullQuoteStr($tableName, 'sys_file_reference') .
				' AND deleted = 0' .
				' AND hidden = 0' .
				' AND uid_foreign=' . intval($uid) .
				' AND fieldname=' . $GLOBALS['TYPO3_DB']->fullQuoteStr($fieldName, 'sys_file_reference'),
			'',
			'sorting_foreign'
		);
		foreach ($references as $referenceRecord) {
			// @note This block is a patch to perform workspace overlay on records.
			if($referenceRecord['t3ver_state'] > 0) {
				continue;
			}
			if ($considerWorkspaces) {
				\TYPO3\CMS\Backend\Utility\BackendUtility::workspaceOL('sys_file_reference', $referenceRecord);
			}
			// end block

			$itemList[] = $this->createFileReferenceObject($referenceRecord);
		}
		return $itemList;
	}

}

?>