#!/bin/bash

#PDF Rendering
 # Clear output directory
    rm -R pdf
    mkdir pdf
 # Render the temporary out.fo file using guide/guide-pdf.xsl (the XSL stylesheet)
    xsltproc --xinclude -o pdf/out.fo guide/guide-pdf.xsl guide/documentation.xml
    cd guide
 # Render out.fo with FOP using fop-config.xml
    fop -c fop-config.xml ../pdf/out.fo ../pdf/out.pdf

