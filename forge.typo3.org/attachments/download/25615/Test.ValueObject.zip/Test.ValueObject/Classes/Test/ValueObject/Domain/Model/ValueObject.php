<?php
namespace Test\ValueObject\Domain\Model;

use TYPO3\Flow\Annotations as Flow;

/**
 * @Flow\ValueObject
 */
class ValueObject {

	/**
	 * @var string
	 */
	protected $value;

	/**
	 * @param string $value
	 */
	public function __construct($value) {
		$this->value = $value;
	}

	/**
	 * @return string
	 */
	public function getValue() {
		return $this->value;
	}

}