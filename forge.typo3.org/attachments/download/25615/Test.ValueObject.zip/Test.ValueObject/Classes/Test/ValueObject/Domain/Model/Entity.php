<?php
namespace Test\ValueObject\Domain\Model;

use Doctrine\Common\Collections\Collection;
use TYPO3\Flow\Annotations as Flow;
use Doctrine\ORM\Mapping as ORM;

/**
 * @Flow\Entity
 */
class Entity {

	/**
	 * @var \Doctrine\Common\Collections\Collection<\Test\ValueObject\Domain\Model\ValueObject>
	 * @ORM\ManyToMany
	 */
	protected $valueObjectCollection;

	/**
	 * @param \Doctrine\Common\Collections\Collection<\Test\ValueObject\Domain\Model\ValueObject> $valueObjectCollection
	 */
	public function setValueObjectCollection($valueObjectCollection) {
		$this->valueObjectCollection = $valueObjectCollection;
	}

	/**
	 * @return \Doctrine\Common\Collections\Collection<\Test\ValueObject\Domain\Model\ValueObject>
	 */
	public function getValueObjectCollection() {
		return $this->valueObjectCollection;
	}

	/**
	 * @param ValueObject $valueObject
	 */
	public function addValueObject(ValueObject $valueObject) {
		$this->valueObjectCollection->add($valueObject);
	}

	/**
	 * @param ValueObject $valueObject
	 */
	public function removeValueObject(ValueObject $valueObject) {
		$this->valueObjectCollection->removeElement($valueObject);
	}

}