<?php

########################################################################
# Extension Manager/Repository config file for ext "mb_fileref".
#
# Auto generated 01-07-2013 11:55
#
# Manual updates:
# Only the data in the array - everything else is removed by next
# writing. "version" and "dependencies" must not be touched!
########################################################################

$EM_CONF[$_EXTKEY] = array(
	'title' => 'Testextension for file references',
	'description' => 'Testextension for file references \'internal_type\' = \'file_reference\'',
	'category' => 'misc',
	'author' => 'Martin Borer',
	'author_email' => 'mbarts@bluewin.ch',
	'shy' => '',
	'dependencies' => '',
	'conflicts' => '',
	'priority' => '',
	'module' => '',
	'state' => 'test',
	'internal' => '',
	'uploadfolder' => 1,
	'createDirs' => '',
	'modify_tables' => '',
	'clearCacheOnLoad' => 0,
	'lockType' => '',
	'author_company' => '',
	'version' => '0.0.0',
	'constraints' => array(
		'depends' => array(
		),
		'conflicts' => array(
		),
		'suggests' => array(
		),
	),
	'_md5_values_when_last_written' => 'a:10:{s:9:"ChangeLog";s:4:"13e9";s:12:"ext_icon.gif";s:4:"1bdc";s:14:"ext_tables.php";s:4:"fe54";s:14:"ext_tables.sql";s:4:"f5fc";s:26:"icon_tx_mbfileref_file.gif";s:4:"355b";s:16:"locallang_db.xml";s:4:"e949";s:10:"README.txt";s:4:"ee2d";s:7:"tca.php";s:4:"4bae";s:19:"doc/wizard_form.dat";s:4:"e6e2";s:20:"doc/wizard_form.html";s:4:"855b";}',
);

?>