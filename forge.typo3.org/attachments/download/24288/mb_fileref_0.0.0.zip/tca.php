<?php
if (!defined('TYPO3_MODE')) {
	die ('Access denied.');
}

$TCA['tx_mbfileref_file'] = array(
	'ctrl' => $TCA['tx_mbfileref_file']['ctrl'],
	'interface' => array(
		'showRecordFieldList' => 'hidden,single_fileref,multiple_fileref,single_file,multiple_file'
	),
	'feInterface' => $TCA['tx_mbfileref_file']['feInterface'],
	'columns' => array(
		'hidden' => array(		
			'exclude' => 1,
			'label'   => 'LLL:EXT:lang/locallang_general.xml:LGL.hidden',
			'config'  => array(
				'type'    => 'check',
				'default' => '0'
			)
		),
		'single_fileref' => array(		
			'exclude' => 0,		
			'label' => 'LLL:EXT:mb_fileref/locallang_db.xml:tx_mbfileref_file.single_fileref',		
			'config' => array(
				'type' => 'group',
				'internal_type' => 'file_reference',
				'allowed' => '',	
				'disallowed' => 'php,php3',	
				'max_size' => $GLOBALS['TYPO3_CONF_VARS']['BE']['maxFileSize'],	
				'show_thumbs' => 1,	
				'size' => 1,	
				'minitems' => 0,
				'maxitems' => 1,
			)
		),
		'multiple_fileref' => array(		
			'exclude' => 0,		
			'label' => 'LLL:EXT:mb_fileref/locallang_db.xml:tx_mbfileref_file.multiple_fileref',		
			'config' => array(
				'type' => 'group',
				'internal_type' => 'file_reference',
				'allowed' => '',	
				'disallowed' => 'php,php3',	
				'max_size' => $GLOBALS['TYPO3_CONF_VARS']['BE']['maxFileSize'],	
				'show_thumbs' => 1,	
				'size' => 5,	
				'minitems' => 0,
				'maxitems' => 10,
			)
		),
		'single_file' => array(		
			'exclude' => 0,		
			'label' => 'LLL:EXT:mb_fileref/locallang_db.xml:tx_mbfileref_file.single_file',		
			'config' => array(
				'type' => 'group',
				'internal_type' => 'file',
				'allowed' => '',	
				'disallowed' => 'php,php3',	
				'max_size' => $GLOBALS['TYPO3_CONF_VARS']['BE']['maxFileSize'],	
				'uploadfolder' => 'uploads/tx_mbfileref',
				'show_thumbs' => 1,	
				'size' => 1,	
				'minitems' => 0,
				'maxitems' => 1,
			)
		),
		'multiple_file' => array(		
			'exclude' => 0,		
			'label' => 'LLL:EXT:mb_fileref/locallang_db.xml:tx_mbfileref_file.multiple_file',		
			'config' => array(
				'type' => 'group',
				'internal_type' => 'file',
				'allowed' => '',	
				'disallowed' => 'php,php3',	
				'max_size' => $GLOBALS['TYPO3_CONF_VARS']['BE']['maxFileSize'],	
				'uploadfolder' => 'uploads/tx_mbfileref',
				'show_thumbs' => 1,	
				'size' => 5,	
				'minitems' => 0,
				'maxitems' => 10,
			)
		),
	),
	'types' => array(
		'0' => array('showitem' => 'hidden;;1;;1-1-1, single_fileref, multiple_fileref, single_file, multiple_file')
	),
	'palettes' => array(
		'1' => array('showitem' => '')
	)
);
?>